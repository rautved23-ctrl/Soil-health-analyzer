import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import {
  Sprout,
  Droplets,
  Thermometer,
  Activity,
  Volume2,
  VolumeX,
  RefreshCw,
  Sliders,
  Radio,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Layers,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Settings2,
  Printer,
  Wifi,
  Usb,
  Cpu,
  ShieldCheck
} from "lucide-react";

const TRANSLATIONS = {
  en: {
    appTitle: "BhoomiMitra - Soil Health Analyser",
    tagline: "Smart Field Soil Telemetry & Crop Advisory System",
    connectionStatus: "Sensor Stream Status",
    liveConnected: "Live Soil Data Active",
    manualMode: "Manual Calibration Mode",
    connectESP32: "Connect Soil Station",
    toggleManual: "Adjust Sliders Manually",
    liveTelemetry: "Telemetry",
    overallScore: "Soil Health Score",
    scoreRemarks: {
      excellent: "Optimal Arable Soil Condition",
      good: "Good Fertility - Minor Adjustments Needed",
      moderate: "Moderate Fertility - Needs Balanced Nutrients",
      poor: "Degraded / Deficient - Needs Immediate Treatment"
    },
    voiceGuidance: "Listen Advisory (Audio)",
    speaking: "Speaking...",
    stopAudio: "Stop Audio",
    parameters: {
      n: { label: "Nitrogen (N)", unit: "mg/kg", desc: "For leafy growth & vitality" },
      p: { label: "Phosphorus (P)", unit: "mg/kg", desc: "For root growth & flower bloom" },
      k: { label: "Potassium (K)", unit: "mg/kg", desc: "For disease resistance & grain yield" },
      ph: { label: "Soil pH", unit: "pH", desc: "Acidity / Alkalinity balance" },
      moisture: { label: "Soil Moisture", unit: "%", desc: "Root zone water content" },
      temp: { label: "Soil Temp", unit: "°C", desc: "Root zone soil temperature" },
      ec: { label: "EC (Salinity)", unit: "µS/cm", desc: "Electrical conductivity / salt content" }
    },
    status: {
      low: "Low",
      optimal: "Optimal",
      high: "High",
      acidic: "Acidic",
      alkaline: "Alkaline",
      neutral: "Optimal (Neutral)",
      dry: "Dry",
      wet: "Waterlogged",
      normal: "Optimal",
      cold: "Cold",
      hot: "Hot",
      lowSaline: "Non-saline",
      medSaline: "Moderate Salt",
      highSaline: "High Saline"
    },
    tabs: {
      overview: "Field Health Dashboard",
      crops: "Recommended Crops",
      fertilizer: "Fertilizer & Treatment",
      healthCard: "Kisan Soil Health Card"
    },
    cropSection: {
      title: "Crop Suitability Match",
      subtitle: "Matched against current N-P-K, pH, moisture, root temperature, and salinity (EC)",
      matchScore: "Suitability",
      idealPH: "Ideal pH",
      idealMoisture: "Target Moisture",
      idealTemp: "Root Temp",
      maxEc: "Max Salinity",
      season: "Season"
    },
    fertilizerSection: {
      title: "Customized Dose & Soil Correction",
      subtitle: "Targeted recommendations per acre for standard yield",
      deficiencies: "Detected Soil Deficiencies & Correction",
      organicRemedy: "Organic & Bio-fertilizer Advisory",
      chemicalDose: "Calculated Fertilizers (Per Acre)",
      irrigationAlert: "Irrigation Action Recommendation"
    },
    irrigation: {
      dry: "Urgent: Soil moisture is below 35%. Schedule a light drip or furrow irrigation cycle today morning/evening.",
      optimal: "Normal: Soil moisture is within the 35% - 60% optimal bracket. No immediate irrigation needed.",
      normal: "Normal: Soil moisture is within the 35% - 60% optimal bracket. No immediate irrigation needed.",
      wet: "Warning: High moisture (>60%). Risk of root fungal wilt. Cease irrigation and ensure proper drainage.",
      waterlogged: "Warning: High moisture (>60%). Risk of root fungal wilt. Cease irrigation and ensure proper drainage."
    },
    printCard: "Print Soil Report",
    resetDefaults: "Reset to Balanced Baseline",
    hardwareSpecs: "ESP32 Direct IoT Soil Station",
    liveSync: {
      active: "Direct ESP32 Telemetry Active",
      awaiting: "Awaiting Sensor Readings",
      lastReading: "Last Reading",
      takeReading: "Take Reading from ESP32",
      readingNow: "Reading Sensors...",
      syncCloud: "Take Reading",
      pauseStream: "Pause Stream",
      resumeStream: "Resume Stream",
      awaitingTitle: "Awaiting True Sensor Readings from ESP32",
      awaitingDesc: "No dummy or estimated data is displayed. Only genuine measurements received directly from the physical ESP32 sensors will appear.",
      checkNow: "Take Reading Now",
      autoPolling: "Auto-refresh: 10s",
      usbConnect: "Connect USB (Serial)",
      usbConnected: "USB Serial Connected",
      usbDisconnect: "Disconnect USB"
    },
    scoreBands: {
      optimal: "80-100: Optimal",
      moderate: "60-79: Moderate",
      low: "45-59: Low Fertility",
      critical: "<45: Critical",
      qualityIndex: "Soil Quality Index",
      viewActions: "View actions",
      awaitingBadge: "Awaiting Data"
    },
    irrigationCard: {
      moistureLabel: "Moisture Level",
      tempLabel: "Soil Temperature",
      footerLeft: "Soil Water Balance",
      footerRight: "Field Ready"
    },
    cropsSnapshot: {
      bestThree: "Best 3",
      suitability: "Match",
      awaitingTitle: "Awaiting Sensor Telemetry",
      awaitingDesc: "Crop rankings will calculate once live data arrives.",
      viewAll: "View All Suitable Crops"
    },
    measurements: {
      heading: "Soil Nutrient & Condition Measurements",
      manualBtn: "Manual Adjuster",
      target: "Target",
      optimal: "Optimal",
      live: "Live",
      pending: "Pending",
      lowSaline: "Non-saline",
      medSaline: "Moderate Salt"
    },
    tuningCard: {
      title: "Manual Soil Testing & Calibration",
      desc: "Simulate custom soil parameters or calibrate readings against local soil test values.",
      openBtn: "Open Controls"
    },
    cropTab: {
      badge: "Real-time match rankings",
      awaitingTitle: "Awaiting Live Soil Telemetry",
      awaitingDesc: "Suitability percentages for regional crops will calculate automatically as soon as real soil data is received.",
      checkSupabase: "Take Reading from ESP32",
      takeReading: "Take Reading from ESP32",
      npkTarget: "N-P-K Target:"
    },
    fertilizerTab: {
      awaitingTitle: "Awaiting Live Soil Telemetry",
      awaitingDesc: "Targeted fertilizer doses, amendments, and organic manure recommendations will calculate automatically once real readings arrive.",
      checkSupabase: "Take Reading from ESP32",
      takeReading: "Take Reading from ESP32",
      colGrade: "Fertilizer Grade",
      colDose: "Calculated Dose / Acre",
      colMethod: "Application Method & Timing",
      colPriority: "Priority",
      allBalanced: "All major macronutrients (N-P-K) are within standard arable targets. Only basal farm compost is suggested.",
      cropSelectorLabel: "Target Crop for Dosage Calculation:",
      autoCrop: "Auto: Top Recommended Crop",
      soilDiagnosisTitle: "Soil Physical & Chemical Condition Diagnosis",
      cropDosingTitle: "Target Crop Chemical Fertilizer Schedule",
      cropDosingSubtitle: "Formulated for target yield based on current soil N-P-K & pH matrix"
    },
    organicAdvice: [
      {
        name: "Vermicompost / Farmyard Manure (FYM)",
        desc: "Apply 2 tons per acre before the last harrowing. Increases beneficial microbial population and soil organic carbon (SOC)."
      },
      {
        name: "Bio-fertilizers (Azospirillum & Rhizobium)",
        desc: "Treat seeds or roots to fix 20-30 kg of atmospheric nitrogen naturally per hectare."
      },
      {
        name: "Neem Cake / Karanj Cake",
        desc: "Apply 100 kg/acre with fertilizers to act as a natural nitrification inhibitor and control soil nematodes."
      }
    ],
    healthCard: {
      title: "DIGITAL SOIL HEALTH CARD",
      subtitle: "BhoomiMitra Automated Agronomy Report",
      cardId: "Card ID",
      date: "Date",
      location: "Location: Maharashtra, India",
      farmerName: "Farmer Name:",
      farmerNameVal: "Shri Kisan Rao",
      surveyNo: "Survey / Gut No:",
      surveyNoVal: "42 / 3A (Vada, Palghar)",
      healthIndex: "Soil Health Index:",
      testMethod: "Testing Method:",
      testMethodVal: "Automated Digital Sensor Analysis",
      tableTitle: "1. Soil Test Chemical & Physical Parameters",
      colParam: "Parameter Name",
      colValue: "Measured Value",
      colRange: "Standard Desirable Range",
      colStatus: "Nutrient Status",
      topCrops: "Top 3 Suitable Crops",
      prescribedDose: "Prescribed Dosage / Acre",
      organicFym: "Organic FYM: 2 Tons / acre compost",
      unitName: "BhoomiMitra Soil Testing Station",
      certAnalysis: "Certified Automated Field Analysis",
      authSign: "Authorized Agronomist Signature",
      awaitingTitle: "Soil Health Card Pending Live Telemetry",
      awaitingDesc: "The official Indian Soil Health Card requires verified sensor measurements. Once real telemetry is received, the certified report will appear automatically."
    },
    configModal: {
      title: "ESP32 Station Settings & Calibration",
      cloudBackend: "Direct ESP32 Hardware Telemetry",
      connected: "Station Connected",
      disconnected: "Disconnected",
      lastSynced: "Last Reading:",
      fetchNow: "Take Reading",
      localIpLabel: "ESP32 IP Address / Hostname",
      localIpDesc: "Connect directly to the on-field station over local Wi-Fi or SoftAP hotspot (Default: 192.168.4.1).",
      softApPreset: "Use Default SoftAP (192.168.4.1)",
      autoRefreshLabel: "Enable Auto-Refresh (Every 10s)",
      autoRefreshDesc: "By default, readings are taken manually on demand so you always know values are freshly sampled.",
      pollBtn: "Save & Read",
      usbSerialLabel: "Direct USB Serial Connection (No Wi-Fi Needed)",
      usbSerialDesc: "Connect your ESP32 directly via USB cable to this device using Web Serial (Chrome / Edge).",
      testValues: "Manual Testing & Calibration Sliders",
      applyBtn: "Apply & Return to Dashboard"
    },
    seasons: {
      Kharif: "Kharif",
      Rabi: "Rabi",
      Annual: "Annual",
      "All season": "All Season",
      "Rabi/Late Kharif": "Rabi / Late Kharif"
    }
  },
  hi: {
    appTitle: "भूमिमित्र - मृदा स्वास्थ्य विश्लेषक",
    tagline: "स्मार्ट खेत मिट्टी परीक्षण एवं किसान फसल परामर्श प्रणाली",
    connectionStatus: "सेंसर कनेक्शन स्थिति",
    liveConnected: "लाइव मिट्टी डेटा चालू है",
    manualMode: "मैन्युअल इनपुट मोड",
    connectESP32: "सेंसर स्टेशन से जुड़ें",
    toggleManual: "मान बदलें (स्लाइडर)",
    liveTelemetry: "लाइव डेटा",
    overallScore: "मृदा स्वास्थ्य स्कोर",
    scoreRemarks: {
      excellent: "उत्कृष्ट एवं उपजाऊ मिट्टी",
      good: "अच्छी उर्वरता - थोड़ा सुधार आवश्यक",
      moderate: "मध्यम स्थिति - संतुलित पोषक तत्वों की जरूरत",
      poor: "कमजोर मिट्टी - तत्काल उपचार और खाद की जरूरत"
    },
    voiceGuidance: "आवाज़ में सुनें (ऑडियो सलाह)",
    speaking: "सुना रहे हैं...",
    stopAudio: "आवाज़ रोकें",
    parameters: {
      n: { label: "नाइट्रोजन (N)", unit: "मिग्रा/किग्रा", desc: "पौधों के विकास एवं हरियाली हेतु" },
      p: { label: "फॉस्फोरस (P)", unit: "मिग्रा/किग्रा", desc: "जड़ों के विकास व फूल बनने हेतु" },
      k: { label: "पोटेशियम (K)", unit: "मिग्रा/किग्रा", desc: "रोग प्रतिरोधक क्षमता और दाने की चमक" },
      ph: { label: "मृदा पीएच (pH)", unit: "pH", desc: "अम्लीय या क्षारीय संतुलन" },
      moisture: { label: "मिट्टी में नमी", unit: "%", desc: "जड़ों के आसपास पानी की मात्रा" },
      temp: { label: "मृदा तापमान", unit: "°C", desc: "जड़ों के आसपास मिट्टी का तापमान" },
      ec: { label: "ईसी / खारापन (EC)", unit: "µS/cm", desc: "मिट्टी में लवण व घुलनशील तत्व" }
    },
    status: {
      low: "कम",
      optimal: "संतुलित",
      high: "अधिक",
      acidic: "अम्लीय (तेज़ाबी)",
      alkaline: "क्षारीय",
      neutral: "संतुलित (उदासीन)",
      dry: "सूखा (कम नमी)",
      wet: "अत्यधिक गीला",
      normal: "संतुलित",
      cold: "ठंडा",
      hot: "गर्म",
      lowSaline: "सामान्य (कम लवण)",
      medSaline: "मध्यम खारा",
      highSaline: "अधिक खारा"
    },
    tabs: {
      overview: "खेत स्थिति डैशबोर्ड",
      crops: "उपयुक्त फसलें",
      fertilizer: "खाद एवं उपचार सलाह",
      healthCard: "किसान मृदा स्वास्थ्य कार्ड"
    },
    cropSection: {
      title: "फसल उपयुक्तता परिणाम",
      subtitle: "वर्तमान N-P-K, pH, नमी, तापमान और खारापन (EC) के आधार पर सबसे उपयुक्त फसलें",
      matchScore: "अनुकूलता",
      idealPH: "उचित पीएच",
      idealMoisture: "उचित नमी",
      idealTemp: "उचित तापमान",
      maxEc: "अधिकतम खारापन",
      season: "मौसम"
    },
    fertilizerSection: {
      title: "खाद की मात्रा व उपचार",
      subtitle: "प्रति एकड़ अनुशंसित जैविक व रासायनिक खुराक",
      deficiencies: "पहचानी गई कमियां एवं सुधार",
      organicRemedy: "जैविक खाद एवं देसी उपचार",
      chemicalDose: "रासायनिक उर्वरक प्रति एकड़ (अनुमानित)",
      irrigationAlert: "सिंचाई सलाह"
    },
    irrigation: {
      dry: "अति आवश्यक: नमी 35% से कम है। कृपया आज शाम या सुबह ड्रिप अथवा हल्की सिंचाई करें।",
      optimal: "संतोषजनक: मिट्टी में 35% - 60% पर्याप्त नमी है। अभी सिंचाई करने की आवश्यकता नहीं है।",
      normal: "संतोषजनक: मिट्टी में 35% - 60% पर्याप्त नमी है। अभी सिंचाई करने की आवश्यकता नहीं है।",
      wet: "चेतावनी: अत्यधिक नमी (>60%)। जड़ों में फफूंद व सड़न का खतरा है। जलनिकासी की व्यवस्था करें।",
      waterlogged: "चेतावनी: अत्यधिक नमी (>60%)। जड़ों में फफूंद व सड़न का खतरा है। जलनिकासी की व्यवस्था करें।"
    },
    printCard: "स्वास्थ्य कार्ड प्रिंट करें",
    resetDefaults: "मानक मान सेट करें",
    hardwareSpecs: "ESP32 सीधा IoT मृदा परीक्षण स्टेशन",
    liveSync: {
      active: "सीधा ESP32 स्टेशन कनेक्शन सक्रिय है",
      awaiting: "सेंसर डेटा की प्रतीक्षा है",
      lastReading: "अंतिम रीडिंग",
      takeReading: "ESP32 से रीडिंग लें",
      readingNow: "सेंसर से रीडिंग ली जा रही है...",
      syncCloud: "रीडिंग लें",
      pauseStream: "रोकें",
      resumeStream: "चालू करें",
      awaitingTitle: "ESP32 से वास्तविक सेंसर डेटा की प्रतीक्षा है",
      awaitingDesc: "कोई भी बनावटी या अनुमानित डेटा नहीं दिखाया जाएगा। केवल भौतिक सेंसरों से प्राप्त वास्तविक रीडिंग प्रदर्शित होगी।",
      checkNow: "अभी रीडिंग लें",
      autoPolling: "स्वतः रिफ्रेश: 10 से.",
      usbConnect: "यूएसबी (सीरियल) से जोड़ें",
      usbConnected: "यूएसबी कनेक्टेड",
      usbDisconnect: "यूएसबी हटाएं"
    },
    scoreBands: {
      optimal: "80-100: उत्तम",
      moderate: "60-79: मध्यम",
      low: "45-59: कम उर्वरता",
      critical: "<45: चिंताजनक",
      qualityIndex: "मृदा गुणवत्ता सूचकांक",
      viewActions: "सलाह देखें",
      awaitingBadge: "डेटा प्रतीक्षारत"
    },
    irrigationCard: {
      moistureLabel: "नमी का स्तर",
      tempLabel: "मिट्टी का तापमान",
      footerLeft: "मृदा जल संतुलन",
      footerRight: "खेत के अनुकूल"
    },
    cropsSnapshot: {
      bestThree: "शीर्ष ३ फसलें",
      suitability: "अनुकूलता",
      awaitingTitle: "सेंसर डेटा की प्रतीक्षा है",
      awaitingDesc: "लाइव डेटा मिलते ही फसल रैंकिंग दिखेगी।",
      viewAll: "सभी उपयुक्त फसलें देखें"
    },
    measurements: {
      heading: "मृदा पोषक तत्व एवं स्थिति माप",
      manualBtn: "मान बदलें",
      target: "मानक लक्ष्य",
      optimal: "संतुलित",
      live: "सक्रिय",
      pending: "प्रतीक्षारत",
      lowSaline: "सामान्य",
      medSaline: "मध्यम खारा"
    },
    tuningCard: {
      title: "मैन्युअल परीक्षण व जांच",
      desc: "विभिन्न परिस्थितियों की जांच हेतु NPK और नमी के मान मैन्युअल रूप से बदलें।",
      openBtn: "कंट्रोल खोलें"
    },
    cropTab: {
      badge: "वास्तविक समय फसल अनुकूलता",
      awaitingTitle: "लाइव मिट्टी डेटा की प्रतीक्षा है",
      awaitingDesc: "खेत से वास्तविक मिट्टी डेटा मिलते ही सभी क्षेत्रीय फसलों की उपयुक्तता स्वतः आ जाएगी।",
      checkSupabase: "ESP32 से रीडिंग लें",
      takeReading: "ESP32 से रीडिंग लें",
      npkTarget: "N-P-K लक्ष्य:"
    },
    fertilizerTab: {
      awaitingTitle: "लाइव मिट्टी डेटा की प्रतीक्षा है",
      awaitingDesc: "मिट्टी की वास्तविक रीडिंग प्राप्त होते ही खाद की खुराक, सुधारक और जैविक उपचार अपने-आप उपलब्ध होंगे।",
      checkSupabase: "ESP32 से रीडिंग लें",
      takeReading: "ESP32 से रीडिंग लें",
      colGrade: "उर्वरक / खाद",
      colDose: "मात्रा प्रति एकड़",
      colMethod: "प्रयोग विधि एवं समय",
      colPriority: "प्राथमिकता",
      allBalanced: "सभी प्रमुख पोषक तत्व (N-P-K) संतुलित स्तर पर हैं। केवल सामान्य गोबर खाद की आवश्यकता है।",
      cropSelectorLabel: "सटीक खाद मात्रा हेतु फसल चुनें:",
      autoCrop: "स्वतः: सर्वश्रेष्ठ उपयुक्त फसल",
      soilDiagnosisTitle: "मृदा भौतिक व रासायनिक दशा निदान (पीएच / खारापन सुधार)",
      cropDosingTitle: "लक्षित फसल अनुसार रासायनिक खाद सारणी",
      cropDosingSubtitle: "वर्तमान N-P-K स्तर व मिट्टी की प्रकृति के आधार पर प्रति एकड़ खुराक"
    },
    organicAdvice: [
      {
        name: "गोबर खाद / केंचुआ खाद (वर्मीकंपोस्ट)",
        desc: "अंतिम जुताई से पहले 2 टन प्रति एकड़ डालें। इससे मिट्टी में जीवांश कार्बन (SOC) और लाभकारी जीवाणु बढ़ते हैं।"
      },
      {
        name: "जैव उर्वरक (एजोटोबैक्टर व राइजोबियम)",
        desc: "बीज अथवा जड़ उपचार करें, जिससे 20-30 किग्रा प्राकृतिक नाइट्रोजन प्रति हेक्टेयर स्वतः उपलब्ध होती है।"
      },
      {
        name: "नीम खली / करंज खली",
        desc: "100 किग्रा प्रति एकड़ खाद के साथ मिलाकर दें; यह दीमक, सफेद लट व नेमाटोड से बचाती है और यूरिया के असर को लंबा रखती है।"
      }
    ],
    healthCard: {
      title: "राष्ट्रीय डिजिटल मृदा स्वास्थ्य कार्ड",
      subtitle: "भूमिमित्र स्वचालित कृषि परीक्षण रिपोर्ट",
      cardId: "कार्ड आईडी",
      date: "दिनांक",
      location: "स्थान: महाराष्ट्र, भारत",
      farmerName: "किसान का नाम:",
      farmerNameVal: "श्री किसान राव",
      surveyNo: "खेत / गट क्रमांक:",
      surveyNoVal: "42 / 3A (वाडा, पालघर)",
      healthIndex: "मृदा स्वास्थ्य स्कोर:",
      testMethod: "परीक्षण विधि:",
      testMethodVal: "स्वचालित डिजिटल सेंसर विश्लेषण",
      tableTitle: "1. मृदा रासायनिक एवं भौतिक परीक्षण परिणाम",
      colParam: "घटक / पोषक तत्व",
      colValue: "मापा गया मान",
      colRange: "आदर्श मानक मात्रा",
      colStatus: "पोषक स्थिति",
      topCrops: "शीर्ष ३ उपयुक्त फसलें",
      prescribedDose: "प्रति एकड़ अनुशंसित खाद मात्रा",
      organicFym: "जैविक खाद: 2 टन प्रति एकड़ अच्छी सड़ी गोबर खाद",
      unitName: "भूमिमित्र डिजिटल मृदा परीक्षण केंद्र",
      certAnalysis: "प्रमाणित स्वचालित डिजिटल मृदा विश्लेषण",
      authSign: "अधिकृत कृषि विशेषज्ञ हस्ताक्षर",
      awaitingTitle: "मृदा स्वास्थ्य कार्ड: लाइव डेटा प्रतीक्षारत",
      awaitingDesc: "आधिकारिक मृदा स्वास्थ्य कार्ड हेतु वास्तविक सेंसर माप आवश्यक है। जैसे ही खेत से डेटा प्राप्त होगा, प्रमाणित रिपोर्ट अपने-आप बन जाएगी।"
    },
    configModal: {
      title: "ESP32 स्टेशन सेटिंग एवं परीक्षण",
      cloudBackend: "सीधा ESP32 हार्डवेयर डेटा",
      connected: "स्टेशन कनेक्टेड",
      disconnected: "डिस्कनेक्टेड",
      lastSynced: "अंतिम रीडिंग:",
      fetchNow: "रीडिंग लें",
      localIpLabel: "ESP32 आईपी पता",
      localIpDesc: "खेत में लगे ESP32 स्टेशन से सीधे लोकल वाई-फाई या हॉटस्पॉट (डिफ़ॉल्ट 192.168.4.1) पर संपर्क।",
      softApPreset: "डिफ़ॉल्ट हॉटस्पॉट सेट करें (192.168.4.1)",
      autoRefreshLabel: "ऑटो-रिफ्रेश चालू करें (हर 10 सेकंड)",
      autoRefreshDesc: "डिफ़ॉल्ट रूप से रीडिंग केवल बटन दबाने पर ली जाती है ताकि केवल वास्तविक रीडिंग प्राप्त हो।",
      pollBtn: "सेव करें व पढ़ें",
      usbSerialLabel: "सीधा यूएसबी सीरियल कनेक्शन (बिना वाई-फाई)",
      usbSerialDesc: "ESP32 को सीधे यूएसबी केबल द्वारा जोड़कर डेटा पढ़ें (Chrome / Edge)।",
      testValues: "मैन्युअल कैलिब्रेशन व परीक्षण मोड",
      applyBtn: "लागू करें और डैशबोर्ड पर जाएं"
    },
    seasons: {
      Kharif: "खरीफ मौसम",
      Rabi: "रबी मौसम",
      Annual: "वार्षिक (सालभर)",
      "All season": "बारहमासी",
      "Rabi/Late Kharif": "रबी / पछेती खरीफ"
    }
  },
  mr: {
    appTitle: "भूमिमित्र - माती आरोग्य विश्लेषक",
    tagline: "स्मार्ट शेत माती परीक्षण आणि शेतकरी पीक सल्लागार प्रणाली",
    connectionStatus: "सेन्सर जोडणी स्थिती",
    liveConnected: "थेट माती डेटा सुरू आहे",
    manualMode: "मॅन्युअल बदल मोड",
    connectESP32: "सेन्सर यंत्रणेशी जोडा",
    toggleManual: "स्लाइडरने मूल्य बदला",
    liveTelemetry: "थेट मोजमाप",
    overallScore: "जमीन आरोग्य निर्देशांक",
    scoreRemarks: {
      excellent: "उत्कृष्ट आणि सुपीक जमीन",
      good: "चांगली सुपीकता - किरकोळ सुधारणा आवश्यक",
      moderate: "मध्यम सुपीकता - समतोल खतांची गरज",
      poor: "कमी सुपीक जमीन - त्वरित सेंद्रिय उपाय आवश्यक"
    },
    voiceGuidance: "सल्ला ऐका (ऑडिओ)",
    speaking: "बोलत आहे...",
    stopAudio: "आवाज थांबवा",
    parameters: {
      n: { label: "नायट्रोजन (N)", unit: "मिग्रॅ/किलो", desc: "पानांची हिरवळ व शाकीय वाढीसाठी" },
      p: { label: "फॉस्फरस / स्फुरद (P)", unit: "मिग्रॅ/किलो", desc: "मुळांची वाढ व फुलोऱ्यासाठी" },
      k: { label: "पोटॅशियम / पालाश (K)", unit: "मिग्रॅ/किलो", desc: "रोगप्रतिकारशक्ती व दाण्यांचा आकार" },
      ph: { label: "जमिनीचा सामू (pH)", unit: "pH", desc: "आम्ल अथवा आम्लारि समतोल" },
      moisture: { label: "मातीतील ओलावा", unit: "%", desc: "मुळांच्या भागातील पाण्याचे प्रमाण" },
      temp: { label: "मातीचे तापमान", unit: "°C", desc: "मुळांच्या भागातील जमिनीचे तापमान" },
      ec: { label: "विद्युत वाहकता (EC)", unit: "µS/cm", desc: "जमिनीतील क्षारता प्रमाण" }
    },
    status: {
      low: "कमी",
      optimal: "योग्य",
      high: "जास्त",
      acidic: "आम्लधर्मी (आंबट)",
      alkaline: "क्षारयुक्त (खारवट)",
      neutral: "योग्य (उदासीन)",
      dry: "कोरडी (कमी ओलावा)",
      wet: "अतिओल (पाणथळ)",
      normal: "योग्य",
      cold: "थंड",
      hot: "उष्ण",
      lowSaline: "सामान्य (अक्षार)",
      medSaline: "मध्यम क्षार",
      highSaline: "जास्त क्षार"
    },
    tabs: {
      overview: "शेत आरोग्य डॅशबोर्ड",
      crops: "योग्य पिके निवडा",
      fertilizer: "खत व्यवस्थापन व उपाय",
      healthCard: "शेतकरी सॉईल हेल्थ कार्ड"
    },
    cropSection: {
      title: "पीक अनुकूलता निष्कर्ष",
      subtitle: "सध्याच्या N-P-K, सामू, ओलावा, तापमान आणि क्षारतेनुसार (EC) शिफारस केलेली पिके",
      matchScore: "अनुकूलता टक्केवारी",
      idealPH: "योग्य सामू (pH)",
      idealMoisture: "योग्य ओलावा",
      idealTemp: "योग्य तापमान",
      maxEc: "कमाल क्षारता (EC)",
      season: "हंगाम"
    },
    fertilizerSection: {
      title: "खत मात्रा व जमीन सुधारणा",
      subtitle: "एकरनिहाय शिफारस केलेले सेंद्रिय व रासायनिक डोस",
      deficiencies: "जमिनीतील कमतरता व उपाय",
      organicRemedy: "सेंद्रिय व जैविक खते उपाय",
      chemicalDose: "रासायनिक खतांची मात्रा (प्रति एकर)",
      irrigationAlert: "पाणी व्यवस्थापन सल्ला"
    },
    irrigation: {
      dry: "तातडीचे: ओलावा ३५% पेक्षा कमी आहे. कृपया आजच ठिबक किंवा हलके पाणी द्या.",
      optimal: "उत्तम: मातीत ३५% ते ६०% पुरेसा ओलावा आहे. सध्यातरी पाणी देण्याची गरज नाही.",
      normal: "उत्तम: मातीत ३५% ते ६०% पुरेसा ओलावा आहे. सध्यातरी पाणी देण्याची गरज नाही.",
      wet: "सावधान: ओलावा जास्त (>६०%) आहे. मुळे सडण्याचा धोका आहे, पाण्याचा निचरा करा.",
      waterlogged: "सावधान: ओलावा जास्त (>६०%) आहे. मुळे सडण्याचा धोका आहे, पाण्याचा निचरा करा."
    },
    printCard: "आरोग्य पत्रिका प्रिंट करा",
    resetDefaults: "प्रमाणित मूल्ये ठेवा",
    hardwareSpecs: "ESP32 थेट IoT माती परीक्षण स्टेशन",
    liveSync: {
      active: "थेट ESP32 स्टेशन जोडणी सुरू आहे",
      awaiting: "सेन्सर डेटाची प्रतीक्षा आहे",
      lastReading: "शेवटची नोंद",
      takeReading: "ESP32 कडून रीडिंग घ्या",
      readingNow: "सेन्सर रीडिंग घेत आहे...",
      syncCloud: "रीडिंग घ्या",
      pauseStream: "थांबवा",
      resumeStream: "सुरू करा",
      awaitingTitle: "ESP32 कडून थेट सेन्सर डेटाची प्रतीक्षा आहे",
      awaitingDesc: "कोणताही बनावट अथवा अंदाजे डेटा दाखवला जात नाही. केवळ भौतिक सेन्सर्सकडून मिळालेली खरी मूल्ये दिसतील.",
      checkNow: "आता रीडिंग घ्या",
      autoPolling: "आपोआप रिफ्रेश: १० सेकंद",
      usbConnect: "USB (सीरियल) द्वारे जोडा",
      usbConnected: "USB कनेक्टेड",
      usbDisconnect: "USB डिस्कनेक्ट करा"
    },
    scoreBands: {
      optimal: "80-100: उत्कृष्ट",
      moderate: "60-79: मध्यम",
      low: "45-59: कमी सुपीकता",
      critical: "<45: चिंताजनक",
      qualityIndex: "माती गुणवत्ता निर्देशांक",
      viewActions: "उपाय पहा",
      awaitingBadge: "डेटा प्रतीक्षेत"
    },
    irrigationCard: {
      moistureLabel: "ओलावा प्रमाण",
      tempLabel: "मातीचे तापमान",
      footerLeft: "जमीन पाणी समतोल",
      footerRight: "शेतीसाठी योग्य"
    },
    cropsSnapshot: {
      bestThree: "सर्वोत्तम ३ पिके",
      suitability: "अनुकूलता",
      awaitingTitle: "सेन्सर डेटाची प्रतीक्षा आहे",
      awaitingDesc: "थेट डेटा मिळताच पिकांची शिफारस दिसेल.",
      viewAll: "सर्व योग्य पिके पहा"
    },
    measurements: {
      heading: "मातीतील अन्नद्रव्ये व स्थिती मोजमाप",
      manualBtn: "मॅन्युअल बदल",
      target: "प्रमाणित मर्यादा",
      optimal: "योग्य",
      live: "थेट",
      pending: "प्रतीक्षेत",
      lowSaline: "सामान्य",
      medSaline: "मध्यम क्षार"
    },
    tuningCard: {
      title: "मॅन्युअल माती चाचणी व सेटिंग",
      desc: "विविध पिके आणि खतांचा सल्ला तपासण्यासाठी NPK व ओलावा मूल्ये मॅन्युअल बदला.",
      openBtn: "कंट्रोल उघडा"
    },
    cropTab: {
      badge: "थेट पीक अनुकूलता",
      awaitingTitle: "थेट माती डेटाची प्रतीक्षा आहे",
      awaitingDesc: "शेतातून थेट माती डेटा येताच सर्व प्रमुख पिकांची अनुकूलता आपोआप गणना केली जाईल.",
      checkSupabase: "ESP32 कडून रीडिंग घ्या",
      takeReading: "ESP32 कडून रीडिंग घ्या",
      npkTarget: "N-P-K उद्दिष्ट:"
    },
    fertilizerTab: {
      awaitingTitle: "थेट माती डेटाची प्रतीक्षा आहे",
      awaitingDesc: "मातीची थेट रीडिंग मिळताच योग्य खत मात्रा, सेंद्रिय उपाय आणि खत व्यवस्थापन येथे उपलब्ध होईल.",
      checkSupabase: "ESP32 कडून रीडिंग घ्या",
      takeReading: "ESP32 कडून रीडिंग घ्या",
      colGrade: "खताचा प्रकार",
      colDose: "प्रमाण प्रति एकर",
      colMethod: "वापरण्याची पद्धत व वेळ",
      colPriority: "प्राधान्य",
      allBalanced: "सर्व प्रमुख अन्नद्रव्ये (N-P-K) योग्य पातळीवर आहेत. फक्त नेहमीचे शेणखत वापरणे पुरेसे आहे.",
      cropSelectorLabel: "अचूक खत डोससाठी पीक निवडा:",
      autoCrop: "आपोआप: सर्वोत्तम शिफारस केलेले पीक",
      soilDiagnosisTitle: "जमिनीची भौतिक व रासायनिक स्थिती निदान (सामू / क्षारता सुधारणा)",
      cropDosingTitle: "पिकानिहाय रासायनिक खत वेळापत्रक",
      cropDosingSubtitle: "जमिनीतील चालू N-P-K व मातीच्या गुणधर्मानुसार एकरनिहाय खत मात्रा"
    },
    organicAdvice: [
      {
        name: "शेणखत / गांडूळ खत",
        desc: "शेताच्या शेवटच्या मशागतीपूर्वी २ टन प्रति एकर मिसळावे. यामुळे जमिनीतील सेंद्रिय कर्ब (SOC) आणि उपयुक्त जिवाणू वाढतात."
      },
      {
        name: "जैविक खते (अझोटोबॅक्टर व रायझोबियम)",
        desc: "बीजप्रक्रिया किंवा मुळांवर प्रक्रिया करा, ज्यामुळे २०-३० किलो नैसर्गिक नत्र हवेतून जमिनीत स्थिर होते."
      },
      {
        name: "निम पेंड / करंज पेंड",
        desc: "१०० किलो प्रति एकर रासायनिक खतात मिसळून द्या; हुमणी व सूत्रकृमींवर नियंत्रण ठेवते आणि खताची कार्यक्षमता वाढवते."
      }
    ],
    healthCard: {
      title: "डिजिटल शेतकरी सॉईल हेल्थ कार्ड",
      subtitle: "भूमिमित्र स्वयंचलित कृषी तपासणी अहवाल",
      cardId: "कार्ड आयडी",
      date: "दिनांक",
      location: "स्थान: महाराष्ट्र, भारत",
      farmerName: "शेतकऱ्याचे नाव:",
      farmerNameVal: "श्री किसान राव",
      surveyNo: "गट / सर्व्हे नंबर:",
      surveyNoVal: "४२ / ३A (वाडा, पालघर)",
      healthIndex: "माती आरोग्य निर्देशांक:",
      testMethod: "चाचणी पद्धत:",
      testMethodVal: "स्वयंचलित डिजिटल सेन्सर विश्लेषण",
      tableTitle: "१. मातीचे रासायनिक व भौतिक तपासणी निष्कर्ष",
      colParam: "घटक नाव",
      colValue: "मोजलेले प्रमाण",
      colRange: "प्रमाणित योग्य मर्यादा",
      colStatus: "पोषक स्थिती",
      topCrops: "सर्वोत्तम ३ योग्य पिके",
      prescribedDose: "प्रति एकर खत मात्रा",
      organicFym: "सेंद्रिय खत: २ टन प्रति एकर चांगले कुजलेले शेणखत",
      unitName: "भूमिमित्र डिजिटल माती परीक्षण केंद्र",
      certAnalysis: "प्रमाणित स्वयंचलित डिजिटल माती विश्लेषण",
      authSign: "अधिकृत कृषी तज्ज्ञ स्वाक्षरी",
      awaitingTitle: "सॉईल हेल्थ कार्ड: थेट डेटा प्रतीक्षेत",
      awaitingDesc: "अधिकृत सॉईल हेल्थ कार्डसाठी सेन्सरचे अचूक मोजमाप आवश्यक आहे. थेट डेटा मिळताच प्रमाणित अहवाल आपोआप तयार होईल."
    },
    configModal: {
      title: "ESP32 सेन्सर सेटिंग व चाचणी",
      cloudBackend: "थेट ESP32 हार्डवेअर डेटा",
      connected: "स्टेशन जोडलेले आहे",
      disconnected: "डिस्कनेक्टेड",
      lastSynced: "शेवटची नोंद:",
      fetchNow: "रीडिंग घ्या",
      localIpLabel: "ESP32 आयपी पत्ता",
      localIpDesc: "शेतातील ESP32 यंत्रणेशी थेट स्थानिक वाय-फाय किंवा हॉटस्पॉटद्वारे (डिफ़ॉल्ट 192.168.4.1) संपर्क.",
      softApPreset: "डिफ़ॉल्ट हॉटस्पॉट वापरा (192.168.4.1)",
      autoRefreshLabel: "आपोआप रिफ्रेश चालू करा (दर १० सेकंद)",
      autoRefreshDesc: "डिफ़ॉल्टनुसार रीडिंग केवळ मागणीनुसार (बटन दाबल्यावर) घेतली जाते.",
      pollBtn: "सेव्ह करा आणि वाचा",
      usbSerialLabel: "थेट USB सीरियल जोडणी (वाय-फाय गरज नाही)",
      usbSerialDesc: "ESP32 ला थेट USB केबलने जोडून डेटा मिळवा (Chrome / Edge).",
      testValues: "मॅन्युअल चाचणी व सेटिंग",
      applyBtn: "लागू करा आणि डॅशबोर्डवर जा"
    },
    seasons: {
      Kharif: "खरीप हंगाम",
      Rabi: "रब्बी हंगाम",
      Annual: "वार्षिक पीक",
      "All season": "सर्व हंगाम",
      "Rabi/Late Kharif": "रब्बी / उशिरा खरीप"
    }
  }
};

const CROP_DATABASE = [
  {
    id: "rice",
    nameEn: "Rice / Paddy",
    nameHi: "धान / चावल (Paddy)",
    nameMr: "भात / धान (Rice)",
    season: "Kharif",
    minN: 90, maxN: 220,
    minP: 20, maxP: 60,
    minK: 120, maxK: 240,
    minPh: 5.5, maxPh: 7.2,
    minMoist: 45, maxMoist: 85,
    minTemp: 20, maxTemp: 36,
    maxEc: 1200,
    icon: "🌾",
    descEn: "Thrives in warm, moisture-rich soils with good nitrogen supply.",
    descHi: "अधिक नमी और संतुलित नाइट्रोजन वाली मिट्टी में बहुत अच्छी उपज देता है।",
    descMr: "चांगला ओलावा आणि मध्यम ते भारी चिकनमातीत भाताचे उत्तम पीक येते."
  },
  {
    id: "wheat",
    nameEn: "Wheat",
    nameHi: "गेहूं (Wheat)",
    nameMr: "गहू (Wheat)",
    season: "Rabi",
    minN: 80, maxN: 180,
    minP: 25, maxP: 65,
    minK: 100, maxK: 200,
    minPh: 6.0, maxPh: 7.8,
    minMoist: 30, maxMoist: 55,
    minTemp: 12, maxTemp: 26,
    maxEc: 1500,
    icon: "🌾",
    descEn: "Prefers well-drained loamy soil with neutral pH and cool temperature.",
    descHi: "दोमट मिट्टी, मध्यम नमी और हल्के ठंडे मौसम के लिए अत्यंत अनुकूल।",
    descMr: "मध्यम ते भारी, पाण्याचा निचरा होणाऱ्या जमिनीत गव्हाचे पीक जोमदार येते."
  },
  {
    id: "cotton",
    nameEn: "Cotton",
    nameHi: "कपास (Cotton)",
    nameMr: "कापूस (Cotton)",
    season: "Kharif",
    minN: 70, maxN: 160,
    minP: 18, maxP: 50,
    minK: 140, maxK: 260,
    minPh: 6.2, maxPh: 8.2,
    minMoist: 25, maxMoist: 50,
    minTemp: 22, maxTemp: 38,
    maxEc: 1800,
    icon: "🌱",
    descEn: "High potassium feeder, deep black soil is ideal with moderate water.",
    descHi: "काली भारी मिट्टी, अधिक पोटाश और मध्यम नमी में शानदार बढ़वार।",
    descMr: "काळी कसदार जमीन व पोटॅशियमची चांगली उपलब्धता कापसाला मानवते."
  },
  {
    id: "soybean",
    nameEn: "Soybean",
    nameHi: "सोयाबीन (Soybean)",
    nameMr: "सोयाबीन (Soybean)",
    season: "Kharif",
    minN: 40, maxN: 120,
    minP: 30, maxP: 75,
    minK: 90, maxK: 190,
    minPh: 6.0, maxPh: 7.5,
    minMoist: 35, maxMoist: 60,
    minTemp: 20, maxTemp: 32,
    maxEc: 1100,
    icon: "🌱",
    descEn: "Leguminous crop requiring good phosphorus for root nodule development.",
    descHi: "दलहनी फसल जिसे जड़ों में गांठ बनने हेतु अच्छे फास्फोरस की जरूरत होती है।",
    descMr: "नत्र स्थिर करणारे पीक असून स्फुरद व उत्तम निचऱ्याची जमीन पोषक ठरते."
  },
  {
    id: "sugarcane",
    nameEn: "Sugarcane",
    nameHi: "गन्ना (Sugarcane)",
    nameMr: "ऊस (Sugarcane)",
    season: "Annual",
    minN: 140, maxN: 300,
    minP: 35, maxP: 90,
    minK: 160, maxK: 320,
    minPh: 6.0, maxPh: 7.9,
    minMoist: 45, maxMoist: 75,
    minTemp: 22, maxTemp: 36,
    maxEc: 1400,
    icon: "🎋",
    descEn: "Heavy feeder crop requiring abundant N, K, and consistent irrigation.",
    descHi: "भारी खुराक वाली फसल जिसे उच्च नाइट्रोजन, पोटाश और निरंतर पानी चाहिए।",
    descMr: "भरपूर नत्र, पालाश आणि मुबलक पाणी लागणारे नगदी पीक."
  },
  {
    id: "onion",
    nameEn: "Onion",
    nameHi: "प्याज (Onion)",
    nameMr: "कांदा (Onion)",
    season: "Rabi/Late Kharif",
    minN: 60, maxN: 130,
    minP: 25, maxP: 65,
    minK: 110, maxK: 210,
    minPh: 6.2, maxPh: 7.5,
    minMoist: 28, maxMoist: 52,
    minTemp: 15, maxTemp: 30,
    maxEc: 1000,
    icon: "🧅",
    descEn: "Requires loose friable soil, moderate nitrogen and high potassium for bulb size.",
    descHi: "कंद के आकार और ठोसपन के लिए पोटाश और भुरभुरी मिट्टी जरूरी।",
    descMr: "भुसभुशीत जमीन व योग्य पालाशमुळे कांद्याचा आकार आणि प्रत सुधारते."
  },
  {
    id: "pulses",
    nameEn: "Gram / Chickpea (Chana)",
    nameHi: "चना (Chickpea)",
    nameMr: "हरभरा (Chana)",
    season: "Rabi",
    minN: 25, maxN: 80,
    minP: 25, maxP: 60,
    minK: 70, maxK: 150,
    minPh: 6.0, maxPh: 7.8,
    minMoist: 20, maxMoist: 45,
    minTemp: 12, maxTemp: 28,
    maxEc: 900,
    icon: "🫘",
    descEn: "Drought hardy, low nitrogen need, requires proper soil drainage.",
    descHi: "कम पानी में होने वाली दलहनी फसल, कम नाइट्रोजन की आवश्यकता।",
    descMr: "कमी पाण्यात येणारे कडधान्य, हलक्या ते मध्यम जमिनीत उत्तम उत्पादन."
  },
  {
    id: "tomato",
    nameEn: "Tomato / Vegetables",
    nameHi: "टमाटर / सब्जी (Tomato)",
    nameMr: "टोमॅटो / भाजीपाला",
    season: "All season",
    minN: 70, maxN: 170,
    minP: 30, maxP: 80,
    minK: 130, maxK: 250,
    minPh: 6.0, maxPh: 7.2,
    minMoist: 35, maxMoist: 60,
    minTemp: 18, maxTemp: 32,
    maxEc: 1100,
    icon: "🍅",
    descEn: "Needs balanced NPK with special focus on Calcium, Potassium and regular moisture.",
    descHi: "संतुलित खाद, फल सड़न से बचाव के लिए नियमित नमी और पोटाश जरूरी।",
    descMr: "उत्तम निचरा आणि नियमित अन्नद्रव्यांचा पुरवठा टोमॅटोसाठी फायदेशीर ठरतो."
  },
  {
    id: "maize",
    nameEn: "Maize / Corn",
    nameHi: "मक्का (Maize)",
    nameMr: "मका (Corn)",
    season: "Kharif",
    minN: 90, maxN: 210,
    minP: 25, maxP: 70,
    minK: 100, maxK: 220,
    minPh: 5.8, maxPh: 7.6,
    minMoist: 30, maxMoist: 55,
    minTemp: 18, maxTemp: 35,
    maxEc: 1200,
    icon: "🌽",
    descEn: "Heavy nitrogen feeder, thrives in warm sunny conditions with well-drained fertile loam.",
    descHi: "अच्छी धूप, गहरी दोमट मिट्टी और उच्च नाइट्रोजन में तेजी से बढ़ती है।",
    descMr: "उत्तम निचरा असलेली जमीन आणि भरपूर नत्र पुरवठा मक्याच्या भरघोस उत्पादनासाठी आवश्यक."
  },
  {
    id: "bajra",
    nameEn: "Pearl Millet (Bajra)",
    nameHi: "बाजरा (Bajra)",
    nameMr: "बाजरी (Pearl Millet)",
    season: "Kharif",
    minN: 35, maxN: 100,
    minP: 15, maxP: 45,
    minK: 60, maxK: 140,
    minPh: 6.0, maxPh: 8.2,
    minMoist: 15, maxMoist: 38,
    minTemp: 22, maxTemp: 40,
    maxEc: 1600,
    icon: "🌾",
    descEn: "Highly drought-hardy, ideal for low-rainfall zones and light sandy loam with low fertility.",
    descHi: "सूखा सहन करने वाली खरीफ फसल, कम पानी और कम खाद वाली हल्की जमीन के लिए सर्वोत्तम।",
    descMr: "कमी पाण्यात व हलक्या जमिनीत येणारे अत्यंत काटक पीक, कोरडवाहू क्षेत्रासाठी आदर्श."
  },
  {
    id: "jowar",
    nameEn: "Sorghum (Jowar)",
    nameHi: "ज्वार (Jowar)",
    nameMr: "ज्वारी (Sorghum)",
    season: "Kharif",
    minN: 50, maxN: 120,
    minP: 20, maxP: 50,
    minK: 80, maxK: 170,
    minPh: 6.0, maxPh: 8.5,
    minMoist: 22, maxMoist: 45,
    minTemp: 20, maxTemp: 38,
    maxEc: 1500,
    icon: "🌾",
    descEn: "Resilient grain crop suited for dryland farming and alkaline or medium-black soils.",
    descHi: "मध्यम काली मिट्टी और कम पानी के लिए उपयुक्त प्रमुख पौष्टिक मोटा अनाज।",
    descMr: "मध्यम ते भारी जमिनीत उत्तम प्रतिसाद देणारे व पाण्याचा ताण सहन करणारे पीक."
  },
  {
    id: "groundnut",
    nameEn: "Groundnut / Peanut",
    nameHi: "मूंगफली (Groundnut)",
    nameMr: "भुईमूग (Peanut)",
    season: "Kharif",
    minN: 30, maxN: 90,
    minP: 25, maxP: 65,
    minK: 80, maxK: 180,
    minPh: 5.8, maxPh: 7.4,
    minMoist: 25, maxMoist: 50,
    minTemp: 20, maxTemp: 34,
    maxEc: 1100,
    icon: "🥜",
    descEn: "Requires light sandy-loam soil with good calcium and phosphorus for pegging and pod filling.",
    descHi: "भुरभुरी रेतीली दोमट मिट्टी, अच्छी फास्फोरस व चूना उपलब्धता में दाना ठोस बनता है।",
    descMr: "भुसभुशीत वाळूमिमिश्रित पोयट्याची जमीन, चांगला स्फुरद व कॅल्शियम शेंगा भरण्यासाठी आवश्यक."
  },
  {
    id: "mustard",
    nameEn: "Mustard / Rapeseed",
    nameHi: "सरसों (Mustard)",
    nameMr: "मोहरी (Mustard)",
    season: "Rabi",
    minN: 60, maxN: 140,
    minP: 20, maxP: 55,
    minK: 70, maxK: 160,
    minPh: 6.0, maxPh: 7.8,
    minMoist: 22, maxMoist: 45,
    minTemp: 12, maxTemp: 25,
    maxEc: 1600,
    icon: "🌼",
    descEn: "Thrives in cool winter temperatures with low moisture; tolerant to mild salinity.",
    descHi: "ठंडे रबी मौसम और कम पानी की आवश्यकता वाली प्रमुख तिलहनी फसल।",
    descMr: "थंड हवामानात व कमी ओलाव्यात उत्तम उत्पादन देणारे रब्बी गळीत पीक."
  },
  {
    id: "potato",
    nameEn: "Potato",
    nameHi: "आलू (Potato)",
    nameMr: "बटाटा (Potato)",
    season: "Rabi",
    minN: 90, maxN: 200,
    minP: 30, maxP: 80,
    minK: 150, maxK: 280,
    minPh: 5.2, maxPh: 6.8,
    minMoist: 35, maxMoist: 60,
    minTemp: 14, maxTemp: 24,
    maxEc: 1000,
    icon: "🥔",
    descEn: "High potassium feeder, prefers cool temperatures, loose friable soil and slightly acidic pH.",
    descHi: "कंद बनने हेतु भारी पोटाश, ठंडी रातें और हल्की भुरभुरी मिट्टी की जरूरत।",
    descMr: "कंदाच्या पोषणासाठी मुबलक पालाश, भुसभुशीत जमीन व थंड हवामान अनुकूल ठरते."
  },
  {
    id: "chilli",
    nameEn: "Chilli / Pepper",
    nameHi: "मिर्च (Chilli)",
    nameMr: "मिरची (Chilli)",
    season: "All season",
    minN: 60, maxN: 150,
    minP: 25, maxP: 65,
    minK: 100, maxK: 220,
    minPh: 6.0, maxPh: 7.5,
    minMoist: 28, maxMoist: 52,
    minTemp: 18, maxTemp: 34,
    maxEc: 1100,
    icon: "🌶️",
    descEn: "Requires warm weather, well-drained loamy soil, sensitive to standing water.",
    descHi: "अच्छे जल निकास वाली दोमट मिट्टी, संतुलित पोटाश व गर्म मौसम में अच्छी फलन।",
    descMr: "पाण्याचा उत्तम निचरा असणारी जमीन व योग्य कीड-रोग व्यवस्थापनात भरपूर उत्पादन."
  },
  {
    id: "turmeric",
    nameEn: "Turmeric / Haldi",
    nameHi: "हल्दी (Turmeric)",
    nameMr: "हळद (Turmeric)",
    season: "Annual",
    minN: 80, maxN: 190,
    minP: 30, maxP: 75,
    minK: 130, maxK: 260,
    minPh: 5.8, maxPh: 7.2,
    minMoist: 38, maxMoist: 65,
    minTemp: 20, maxTemp: 35,
    maxEc: 1200,
    icon: "🌿",
    descEn: "Requires rich organic soil, high potassium for rhizome growth, and steady moisture.",
    descHi: "गठिया बनने के लिए भरपूर जैविक खाद, पोटाश और नियमित हल्की सिंचाई आवश्यक।",
    descMr: "सेंद्रिय खतांचा भरपूर पुरवठा, चांगला पालाश व ओल हळदीच्या उत्पादनासाठी महत्त्वाची."
  }
];

const ZERO_SENSORS = {
  nitrogen: 0,
  phosphorus: 0,
  potassium: 0,
  ph: 0,
  moisture: 0,
  temperature: 0,
  ec: 0
};

const DEFAULT_SENSORS = {
  nitrogen: 88,      // mg/kg
  phosphorus: 24,    // mg/kg
  potassium: 145,    // mg/kg
  ph: 6.6,           // pH unit
  moisture: 38.5,    // percentage
  temperature: 26.4, // Celsius
  ec: 480            // microSiemens/cm
};

export default function App() {
  const [lang, setLang] = useState("en"); // 'en' | 'hi' | 'mr'
  const [activeTab, setActiveTab] = useState("overview"); // 'overview' | 'crops' | 'fertilizer' | 'healthCard'
  const [autoRefresh, setAutoRefresh] = useState(false); // Default FALSE: readings taken manually on demand
  const [sensorData, setSensorData] = useState(ZERO_SENSORS);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [lastReadingTime, setLastReadingTime] = useState(null);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [espIp, setEspIp] = useState(() => localStorage.getItem("bhoomimitra_esp_ip") || "192.168.4.1");
  const [hardwareConnected, setHardwareConnected] = useState(false);
  const [isTakingReading, setIsTakingReading] = useState(false);
  const [selectedFertilizerCrop, setSelectedFertilizerCrop] = useState("auto");
  const [isStationOffline, setIsStationOffline] = useState(true);
  const [sensorStatus, setSensorStatus] = useState({
    npkConnected: false,
    tempConnected: false,
    moistureConnected: false,
    errorMessage: ""
  });
  const [usbConnected, setUsbConnected] = useState(false);
  const serialPortRef = useRef(null);
  const serialReaderRef = useRef(null);

  const t = TRANSLATIONS[lang] || TRANSLATIONS.en;

  const isWebSerialSupported = typeof navigator !== "undefined" && "serial" in navigator;

  // Take readings directly from ESP32 - ZERO artificial estimation, pure physical sensor values
  const takeReadingFromEsp32 = useCallback(async (triggerFresh = true) => {
    setIsTakingReading(true);
    const cleanIp = espIp.trim().replace(/^https?:\/\//, '').replace(/\/$/, '');
    localStorage.setItem("bhoomimitra_esp_ip", cleanIp);

    const endpoint = triggerFresh ? "/api/read" : "/api/readings";
    const directUrl = "http://" + cleanIp + endpoint;
    const proxyUrl = "/esp-proxy" + endpoint;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);

    let data = null;
    let fetchError = null;

    try {
      const res = await fetch(directUrl, {
        method: triggerFresh ? "POST" : "GET",
        signal: controller.signal,
        headers: { "Accept": "application/json" }
      }).catch(async (err) => {
        // Fallback to Vite dev proxy if on localhost
        if (window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1") {
          return await fetch(proxyUrl, {
            method: triggerFresh ? "POST" : "GET",
            signal: controller.signal,
            headers: { "Accept": "application/json" }
          });
        }
        throw err;
      });

      if (res && res.ok) {
        data = await res.json();
      } else {
        throw new Error("ESP32 returned HTTP error " + (res ? res.status : "unknown"));
      }
    } catch (err) {
      fetchError = err.message || "Failed to reach ESP32";
    } finally {
      clearTimeout(timeoutId);
    }

    if (data && data.status === "ok") {
      // Received true physical sensor values directly from ESP32
      const rawN = Number(data.nitrogen ?? 0);
      const rawP = Number(data.phosphorus ?? 0);
      const rawK = Number(data.potassium ?? 0);
      const rawPh = Number(data.ph ?? 0);
      const rawMoisture = Number(data.moisture ?? 0);
      const rawTemp = Number(data.temperature ?? 0);
      const rawEc = Number(data.ec ?? 0);

      const npkConn = Boolean(data.sensor_status?.npk_connected);
      const tempConn = Boolean(data.sensor_status?.temp_connected);
      const moistConn = Boolean(data.sensor_status?.moisture_connected);

      // ONLY TRUE PHYSICAL SENSOR DATA - ZERO SYNTHESIS
      setSensorData({
        nitrogen: rawN,
        phosphorus: rawP,
        potassium: rawK,
        ph: rawPh,
        moisture: rawMoisture,
        temperature: rawTemp,
        ec: rawEc
      });

      setSensorStatus({
        npkConnected: npkConn,
        tempConnected: tempConn,
        moistureConnected: moistConn,
        errorMessage: ""
      });

      setHardwareConnected(true);
      setIsStationOffline(false);
      setLastReadingTime(new Date().toLocaleTimeString());
    } else {
      setHardwareConnected(false);
      setSensorStatus(prev => ({
        ...prev,
        errorMessage: fetchError || "Could not reach ESP32 at " + cleanIp + ". Check Wi-Fi / SoftAP connection."
      }));
    }

    setIsTakingReading(false);
  }, [espIp]);

  // Direct USB Web Serial connection (no network needed)
  const connectUsbSerial = async () => {
    if (!isWebSerialSupported) {
      alert("Web Serial is available in Google Chrome, Microsoft Edge, and Opera browsers.");
      return;
    }

    try {
      if (usbConnected && serialPortRef.current) {
        if (serialReaderRef.current) {
          try { await serialReaderRef.current.cancel(); } catch { /* ignore */ }
        }
        await serialPortRef.current.close();
        serialPortRef.current = null;
        setUsbConnected(false);
        return;
      }

      setIsTakingReading(true);
      const port = await navigator.serial.requestPort();
      await port.open({ baudRate: 115200 });
      serialPortRef.current = port;
      setUsbConnected(true);

      const encoder = new TextEncoder();
      const writer = port.writable.getWriter();
      await writer.write(encoder.encode("READ\n"));
      writer.releaseLock();

      const textDecoder = new TextDecoderStream();
      port.readable.pipeTo(textDecoder.writable);
      const reader = textDecoder.readable.getReader();
      serialReaderRef.current = reader;

      let accumulated = "";
      const timeout = setTimeout(() => {
        try { reader.cancel(); } catch { /* ignore */ }
      }, 5000);

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        if (value) {
          accumulated += value;
          const lines = accumulated.split("\n");
          for (const line of lines) {
            const trimmed = line.trim();
            if (trimmed.startsWith("{") && trimmed.includes('"nitrogen"')) {
              try {
                const parsed = JSON.parse(trimmed);
                clearTimeout(timeout);
                setSensorData({
                  nitrogen: Number(parsed.nitrogen ?? 0),
                  phosphorus: Number(parsed.phosphorus ?? 0),
                  potassium: Number(parsed.potassium ?? 0),
                  ph: Number(parsed.ph ?? 0),
                  moisture: Number(parsed.moisture ?? 0),
                  temperature: Number(parsed.temperature ?? 0),
                  ec: Number(parsed.ec ?? 0)
                });
                setSensorStatus({
                  npkConnected: Boolean(parsed.sensor_status?.npk_connected),
                  tempConnected: Boolean(parsed.sensor_status?.temp_connected),
                  moistureConnected: Boolean(parsed.sensor_status?.moisture_connected),
                  errorMessage: ""
                });
                setHardwareConnected(true);
                setIsStationOffline(false);
                setLastReadingTime(new Date().toLocaleTimeString());
                setIsTakingReading(false);
                return;
              } catch {
                // Continue searching for complete JSON
              }
            }
          }
        }
      }
    } catch (err) {
      console.warn("Serial error:", err);
      setUsbConnected(false);
    } finally {
      setIsTakingReading(false);
    }
  };

  useEffect(() => {
    let interval = null;
    if (autoRefresh) {
      interval = setInterval(() => {
        takeReadingFromEsp32(false);
      }, 10000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [autoRefresh, takeReadingFromEsp32]);

  const soilAnalysis = useMemo(() => {
    if (!sensorData) return null;
    const { nitrogen, phosphorus, potassium, ph, moisture, temperature, ec } = sensorData;

    // When station is offline or moisture & temp are 0:
    const isOfflineOrZero = isStationOffline ||
      (nitrogen === 0 && phosphorus === 0 && potassium === 0 && ph === 0 && moisture === 0 && temperature === 0);

    if (isOfflineOrZero) {
      return {
        totalScore: 0,
        category: "poor",
        nStatus: "low",
        pStatus: "low",
        kStatus: "low",
        phStatus: "neutral",
        mStatus: "dry",
        tempStatus: "cold",
        ecStatus: "lowSaline",
        isOfflineOrZero: true
      };
    }

    // Helper score evaluators strictly matching displayed target brackets:
    // N Target: 100 - 220 mg/kg
    let nScore = 100;
    if (nitrogen < 100) nScore = Math.max(0, Math.round((nitrogen / 100) * 85));
    else if (nitrogen > 220) nScore = Math.max(40, 100 - (nitrogen - 220) * 0.4);
    else nScore = 98;

    // P Target: 25 - 60 mg/kg
    let pScore = 100;
    if (phosphorus < 25) pScore = Math.max(0, Math.round((phosphorus / 25) * 85));
    else if (phosphorus > 60) pScore = Math.max(40, 100 - (phosphorus - 60) * 0.8);
    else pScore = 98;

    // K Target: 120 - 250 mg/kg
    let kScore = 100;
    if (potassium < 120) kScore = Math.max(0, Math.round((potassium / 120) * 85));
    else if (potassium > 250) kScore = Math.max(40, 100 - (potassium - 250) * 0.3);
    else kScore = 98;

    // pH Target: 6.2 - 7.5
    let phScore = 100;
    if (ph < 6.2) phScore = Math.max(25, 100 - (6.2 - ph) * 45);
    else if (ph > 7.5) phScore = Math.max(25, 100 - (ph - 7.5) * 40);
    else phScore = 98;

    // Moisture Target: 35% - 60%
    let mScore = 100;
    if (moisture < 35) mScore = Math.max(20, (moisture / 35) * 80);
    else if (moisture > 60) mScore = Math.max(30, 100 - (moisture - 60) * 1.5);
    else mScore = 98;

    // Temperature Target: 18 - 32 °C
    let tempScore = 100;
    if (temperature < 18) tempScore = Math.max(30, 100 - (18 - temperature) * 5);
    else if (temperature > 32) tempScore = Math.max(30, 100 - (temperature - 32) * 5);
    else tempScore = 98;

    // EC Target: < 1000 µS/cm (< 800 optimal)
    let ecScore = 100;
    if (ec < 800) ecScore = 98;
    else if (ec <= 1200) ecScore = 75;
    else ecScore = Math.max(25, 75 - (ec - 1200) * 0.05);

    const totalScore = Math.round(
      nScore * 0.22 +
      pScore * 0.18 +
      kScore * 0.18 +
      phScore * 0.15 +
      mScore * 0.12 +
      tempScore * 0.08 +
      ecScore * 0.07
    );

    // Status classifications strictly aligning with displayed target ranges:
    const nStatus = nitrogen < 100 ? "low" : nitrogen > 220 ? "high" : "optimal";
    const pStatus = phosphorus < 25 ? "low" : phosphorus > 60 ? "high" : "optimal";
    const kStatus = potassium < 120 ? "low" : potassium > 250 ? "high" : "optimal";
    const phStatus = ph < 6.2 ? "acidic" : ph > 7.5 ? "alkaline" : "neutral";
    const mStatus = moisture < 35 ? "dry" : moisture > 60 ? "wet" : "optimal";
    const tempStatus = temperature < 18 ? "cold" : temperature > 32 ? "hot" : "optimal";
    const ecStatus = ec < 800 ? "lowSaline" : ec <= 1200 ? "medSaline" : "highSaline";

    let category = "good";
    if (totalScore >= 85) category = "excellent";
    else if (totalScore >= 68) category = "good";
    else if (totalScore >= 50) category = "moderate";
    else category = "poor";

    return {
      totalScore: Math.min(100, Math.max(10, totalScore)),
      category,
      nStatus,
      pStatus,
      kStatus,
      phStatus,
      mStatus,
      tempStatus,
      ecStatus
    };
  }, [sensorData, isStationOffline]);

  const cropRecommendations = useMemo(() => {
    if (isStationOffline || !sensorData || sensorData.moisture <= 0 || sensorData.temperature <= 0) return [];
    const { nitrogen, phosphorus, potassium, ph, moisture, temperature, ec = 0 } = sensorData;

    return CROP_DATABASE.map(crop => {
      // 1. Moisture Suitability (Weight: 25%) - Essential survival factor
      let mFit = 100;
      if (moisture < crop.minMoist) {
        const deficit = crop.minMoist - moisture;
        mFit = Math.max(10, 100 - deficit * 2.8);
      } else if (moisture > crop.maxMoist) {
        const surplus = moisture - crop.maxMoist;
        mFit = Math.max(15, 100 - surplus * 2.4);
      }

      // 2. Soil pH Suitability (Weight: 20%) - Chemical bioavailability & root uptake
      let phFit = 100;
      if (ph < crop.minPh) {
        const diff = crop.minPh - ph;
        phFit = Math.max(15, 100 - diff * 45);
      } else if (ph > crop.maxPh) {
        const diff = ph - crop.maxPh;
        phFit = Math.max(15, 100 - diff * 40);
      }

      // 3. Root Zone Temperature (Weight: 15%) - Seasonal thermal window
      let tempFit = 100;
      if (temperature < crop.minTemp) {
        const diff = crop.minTemp - temperature;
        tempFit = Math.max(10, 100 - diff * 8.0);
      } else if (temperature > crop.maxTemp) {
        const diff = temperature - crop.maxTemp;
        tempFit = Math.max(10, 100 - diff * 7.0);
      }

      // 4. Salinity / EC Tolerance (Weight: 10%) - Osmotic moisture absorption
      let ecFit = 100;
      const cropMaxEc = crop.maxEc || 1200;
      if (ec > cropMaxEc) {
        const excess = ec - cropMaxEc;
        ecFit = Math.max(20, 100 - (excess / 250) * 20);
      }

      // 5. N-P-K Macronutrient Suitability (Weight: 30%)
      // Nitrogen
      let nFit = 100;
      if (nitrogen < crop.minN) {
        nFit = crop.minN > 0 ? Math.max(0, Math.round((nitrogen / crop.minN) * 100)) : 100;
      } else if (nitrogen > crop.maxN) {
        const excess = nitrogen - crop.maxN;
        nFit = Math.max(65, 100 - (excess / crop.maxN) * 30);
      }

      // Phosphorus
      let pFit = 100;
      if (phosphorus < crop.minP) {
        pFit = crop.minP > 0 ? Math.max(0, Math.round((phosphorus / crop.minP) * 100)) : 100;
      } else if (phosphorus > crop.maxP) {
        const excess = phosphorus - crop.maxP;
        pFit = Math.max(70, 100 - (excess / crop.maxP) * 25);
      }

      // Potassium
      let kFit = 100;
      if (potassium < crop.minK) {
        kFit = crop.minK > 0 ? Math.max(0, Math.round((potassium / crop.minK) * 100)) : 100;
      } else if (potassium > crop.maxK) {
        const excess = potassium - crop.maxK;
        kFit = Math.max(70, 100 - (excess / crop.maxK) * 25);
      }

      const npkFit = (nFit * 0.40) + (pFit * 0.30) + (kFit * 0.30);

      // Weighted Multi-Factor Agronomic Base
      let score = (mFit * 0.25) + (phFit * 0.20) + (tempFit * 0.15) + (ecFit * 0.10) + (npkFit * 0.30);

      // Agronomic Bottleneck: Liebig's Law of the Minimum
      // Historically formulated by Justus von Liebig: crop yield is determined not by total resources,
      // but by the scarcest nutrient or factor (Moisture, pH, Temp, EC, Nitrogen, Phosphorus, Potassium).
      // If ANY essential factor is severely deficient (< 50%), the overall suitability collapses.
      const criticalBottleneck = Math.min(mFit, phFit, tempFit, ecFit, nFit, pFit, kFit);
      if (criticalBottleneck < 50) {
        score = Math.min(score, Math.max(15, criticalBottleneck * 1.3));
      }

      const finalMatch = Math.round(Math.max(15, Math.min(98, score)));

      let cropName = crop.nameEn;
      let cropDesc = crop.descEn;
      if (lang === "hi") {
        cropName = crop.nameHi;
        cropDesc = crop.descHi;
      } else if (lang === "mr") {
        cropName = crop.nameMr;
        cropDesc = crop.descMr;
      }

      return {
        ...crop,
        displayName: cropName,
        displayDesc: cropDesc,
        matchScore: finalMatch
      };
    }).sort((a, b) => b.matchScore - a.matchScore);
  }, [sensorData, lang, isStationOffline]);

  const fertilizerAdvice = useMemo(() => {
    if (isStationOffline || !sensorData || sensorData.moisture <= 0 || sensorData.temperature <= 0) return { recommendations: [], chemicalDoses: [], targetCrop: null };
    const { nitrogen, phosphorus, potassium, ph, moisture, ec = 0 } = sensorData;
    const items = [];
    const chemicalItems = [];

    // 1. Resolve Target Crop (selected or auto top recommendation)
    const activeCropId = selectedFertilizerCrop === "auto" 
      ? (cropRecommendations[0]?.id || "wheat") 
      : selectedFertilizerCrop;
    const targetCrop = CROP_DATABASE.find(c => c.id === activeCropId) || CROP_DATABASE[0];

    const isLegume = ["pulses", "soybean", "groundnut"].includes(targetCrop.id);
    const isHeavyFeeder = ["sugarcane", "maize", "cotton", "turmeric"].includes(targetCrop.id);
    const isTuberCrop = ["potato", "onion"].includes(targetCrop.id);

    // 2. SOIL MATRIX DIAGNOSIS (pH, Salinity, Moisture, Excess Nutrients)

    // A. Soil Reaction (pH Diagnosis)
    if (ph < 6.2) {
      items.push({
        titleEn: `Acidic Soil Stress (pH ${ph.toFixed(1)})`,
        titleHi: `अम्लीय मिट्टी समस्या (पीएच ${ph.toFixed(1)})`,
        titleMr: `आम्लयुक्त जमीन ताण (सामू ${ph.toFixed(1)})`,
        severity: ph < 5.5 ? "critical" : "warning",
        actionEn: `Free Iron & Aluminum fix soluble phosphorus into insoluble forms. Apply Agricultural Lime / Dolomite @ ${ph < 5.5 ? '250 - 350' : '150 - 250'} kg/acre 2 weeks prior to sowing. Strongly prefer SSP over DAP as SSP supplies 19% Calcium & 11% Sulfur to buffer soil acidity.`,
        actionHi: `अम्लीय मिट्टी में फास्फोरस जम जाता है। बुवाई से पूर्व ${ph < 5.5 ? '250 - 350' : '150 - 250'} किग्रा कृषि चूना प्रति एकड़ मिलाएं। डीएपी के स्थान पर एसएसपी को प्राथमिकता दें क्योंकि यह आवश्यक कैल्शियम व सल्फर प्रदान करता है।`,
        actionMr: `आम्लधर्मी जमिनीत स्फुरद अविद्राव्य होतो. पेरणीपूर्वी एकरी ${ph < 5.5 ? '२५० - ३५०' : '१५० - २५०'} किलो कृषी चुना मिसळावा. डीएपी ऐवजी एसएसपी वापरावे, ज्यातून कॅल्शियम व गंधक मिळून आम्लता कमी होते.`
      });
    } else if (ph > 7.5) {
      items.push({
        titleEn: `Alkaline & Sodic Stress (pH ${ph.toFixed(1)})`,
        titleHi: `क्षारीय / उसर मिट्टी समस्या (पीएच ${ph.toFixed(1)})`,
        titleMr: `क्षारयुक्त / चोपण जमीन समस्या (सामू ${ph.toFixed(1)})`,
        severity: ph > 8.2 ? "critical" : "warning",
        actionEn: `High calcium & sodium lock phosphorus and cause up to 35% ammonia volatilization from surface Urea. Incorporate Agricultural Gypsum @ ${ph > 8.2 ? '400 - 600' : '250 - 400'} kg/acre or Agricultural Sulfur @ 25 kg/acre. Always place fertilizers 5 cm deep in the seed furrow (never surface-broadcast). Apply 10 kg/acre Zinc Sulfate (ZnSO4 21%) to prevent zinc deficiency.`,
        actionHi: `उच्च क्षारीयता में फास्फोरस बंध जाता है और यूरिया से 35% अमोनिया गैस बनकर उड़ जाती है। एकरी ${ph > 8.2 ? '400 - 600' : '250 - 400'} किग्रा जिप्सम अथवा 25 किग्रा सल्फर डालें। खाद को सतह पर न छिड़कें, हमेशा 5 सेमी गहराई में डालें और 10 किग्रा जिंक सल्फेट दें।`,
        actionMr: `चोपण जमिनीत नत्र हवेत उडून जातो व सूक्ष्म अन्नद्रव्ये उपलब्ध होत नाहीत. एकरी ${ph > 8.2 ? '४०० - ६००' : '२५० - ४००'} किलो जिप्सम किंवा २५ किलो गंधक मिसळावे. रासायनिक खते वर न टाकता ५ सेमी जमिनीत गाडून द्यावीत आणि १० किलो झिंक सल्फेट वापरावे.`
      });
    }

    // B. Salinity / EC Diagnosis
    if (ec > 1200) {
      items.push({
        titleEn: `Saline Osmotic Stress (EC: ${ec} µS/cm)`,
        titleHi: `लवणता / खारापन तनाव (EC: ${ec} µS/cm)`,
        titleMr: `क्षारपड जमिनीचा ताण (EC: ${ec} µS/cm)`,
        severity: "critical",
        actionEn: `High soluble salts inhibit root osmotic absorption. AVOID Muriate of Potash (MOP / KCl) as chlorine burns root hairs; use Sulfate of Potash (SOP / 0:0:50) instead. Perform heavy pre-sowing leaching irrigation and incorporate 2 tons/acre compost to buffer salts.`,
        actionHi: `अत्यधिक खारापन जड़ों को पानी सोखने से रोकता है। एमओपी (पोटाश) का प्रयोग न करें क्योंकि इसमें क्लोरीन होता है; इसकी जगह एसओपी (सल्फेट ऑफ पोटाश 0:0:50) का उपयोग करें। बुवाई से पूर्व भारी सिंचाई करके लवण नीचे बहाएं।`,
        actionMr: `जास्त क्षार मुळांना पाणी घेण्यास अडथळा निर्माण करतात. एमओपी (पालाश) टाळावे कारण त्यातील क्लोरीन मुळांना जाळतो; त्याऐवजी एसओपी (सल्फेट ऑफ पोटॅश ०:०:५०) वापरावे. पेरणीपूर्वी भरपूर पाणी देऊन क्षार धुवून काढावेत.`
      });
    } else if (ec >= 800 && ec <= 1200) {
      items.push({
        titleEn: `Moderate Salinity (EC: ${ec} µS/cm)`,
        titleHi: `मध्यम लवणता (EC: ${ec} µS/cm)`,
        titleMr: `मध्यम क्षारता (EC: ${ec} µS/cm)`,
        actionEn: `Maintain good field drainage furrows. Avoid chloride-heavy fertilizers for salt-sensitive crops (pulses, onions).`,
        actionHi: `खेत में जलनिकासी की उचित व्यवस्था रखें। दलहन व प्याज जैसी संवेदनशील फसलों में क्लोराइड युक्त खादों से बचें।`,
        actionMr: `पाण्याचा चांगला निचरा ठेवा. कडधान्य व कांदा पिकांसाठी जास्त क्षार निर्माण करणारी खते टाळा.`
      });
    }

    // C. Moisture Condition
    if (moisture < 35) {
      items.push({
        titleEn: `Dry Root Zone (${moisture}%) - Fertilizer Salt Burn Risk`,
        titleHi: `कम नमी (${moisture}%) - रासायनिक खाद से जड़ जलने का खतरा`,
        titleMr: `कमी ओलावा (${moisture}%) - खतांमुळे मुळे करपण्याचा धोका`,
        actionEn: `Never apply chemical fertilizers into dry soil without water (concentrated fertilizer salts burn root tissue). Apply via fertigation or irrigate immediately after basal dressing.`,
        actionHi: `सूखी मिट्टी में रासायनिक खाद कभी न डालें, इससे जड़ें झुलस सकती हैं। खाद देने के तुरंत बाद सिंचाई करें अथवा ड्रिप से दें।`,
        actionMr: `कोरड्या जमिनीत रासायनिक खते टाकू नका, यामुळे मुळे करपतात. खते दिल्यानंतर लगेच पाणी द्या किंवा ठिबकद्वारे द्या.`
      });
    } else if (moisture > 60) {
      items.push({
        titleEn: `High Moisture (${moisture}%) - Denitrification & Leaching Risk`,
        titleHi: `अत्यधिक नमी (${moisture}%) - खाद बहने व गैस बनने का खतरा`,
        titleMr: `जास्त ओलावा (${moisture}%) - नत्र वाहून जाण्याचा धोका`,
        actionEn: `Waterlogged soil causes anaerobic denitrification and nitrate leaching. Cease chemical top-dressing until excess water is drained out and soil aerates.`,
        actionHi: `पानी भरे रहने से नाइट्रोजन गैस बनकर उड़ जाती है। जब तक अतिरिक्त पानी न निकले, तब तक यूरिया का छिड़काव न करें।`,
        actionMr: `जमिनीत पाणी साचल्यास खत वाहून जाते. अतिरिक्त पाणी बाहेर काढल्याशिवाय खतांचा वरखत डोस देऊ नका.`
      });
    }

    // D. Nutrient Toxicity / Excess Alerts
    if (nitrogen > targetCrop.maxN) {
      items.push({
        titleEn: `Excess Soil Nitrogen (${nitrogen} mg/kg)`,
        titleHi: `नाइट्रोजन की अधिकता (${nitrogen} mg/kg)`,
        titleMr: `नत्राचे अतिरिक्त प्रमाण (${nitrogen} mg/kg)`,
        actionEn: `High nitrogen causes vegetative lodging, weak succulence, delayed grain maturity, and heavy pest attacks. Withhold all Urea and nitrogenous fertilizers. Apply Potash to strengthen plant stalks.`,
        actionHi: `अधिक नाइट्रोजन से पौधे कमजोर होकर गिर जाते हैं और कीटों का प्रकोप बढ़ता है। यूरिया पूरी तरह रोकें और पोटाश देकर पौधे को मजबूत करें।`,
        actionMr: `अतिरिक्त नत्रामुळे पीक लोळते आणि कीड-रोगांचा प्रादुर्भाव वाढतो. युरिया पूर्णपणे बंद करावा आणि खोड मजबूत करण्यासाठी पालाश द्यावा.`
      });
    }

    if (phosphorus > targetCrop.maxP) {
      items.push({
        titleEn: `Excess Soil Phosphorus (${phosphorus} mg/kg)`,
        titleHi: `फास्फोरस की अधिकता (${phosphorus} mg/kg)`,
        titleMr: `स्फुरदाचे अतिरिक्त प्रमाण (${phosphorus} mg/kg)`,
        actionEn: `Excess phosphorus induces Zinc (Zn) and Iron (Fe) chlorosis. Stop all DAP/SSP application. Apply foliar spray of 0.5% Zinc Sulfate to relieve micronutrient block.`,
        actionHi: `अत्यधिक फास्फोरस से पौधों को जिंक और लोहा नहीं मिल पाता। डीएपी/एसएसपी न दें और 0.5% जिंक सल्फेट का छिड़काव करें।`,
        actionMr: `जास्त स्फुरदामुळे जस्त (झिंक) आणि लोह यांची कमतरता जाणवते. डीएपी/एसएसपी बंद करा आणि ०.५% झिंक सल्फेटची फवारणी करा.`
      });
    }

    // 3. TARGET CROP CHEMICAL FERTILIZER DOSING TABLE

    // A. NITROGEN DOSING
    if (nitrogen < targetCrop.minN) {
      const deficit = targetCrop.minN - nitrogen;
      if (isLegume) {
        // Legume crops fix atmospheric N; only need starter N
        chemicalItems.push({
          nameEn: "Urea (46% N) - Starter Dose",
          nameHi: "यूरिया (46% नत्र) - शुरुआती स्टार्टर खुराक",
          nameMr: "युरिया (४६% नत्र) - सुरुवातीचा स्टार्टर डोस",
          dose: "15 - 20 kg / acre",
          timingEn: "Apply strictly at sowing as starter. Avoid top-dressing as excess nitrogen suppresses root nodule formation.",
          timingHi: "केवल बुवाई के समय दें। बाद में न दें, अधिक नाइट्रोजन से जड़ों में प्राकृतिक गांठें बनना रुक जाती हैं।",
          timingMr: "फक्त पेरणीवेळी द्यावे. नंतर युरिया देऊ नये, जास्त नत्रामुळे मुळांवरील गाठींची वाढ खुंटते.",
          tag: "Starter N",
          tagHi: "शुरुआती नत्र",
          tagMr: "स्टार्टर नत्र"
        });
      } else {
        const factor = isHeavyFeeder ? 1.4 : 1.25;
        const ureaKg = Math.round(deficit * factor);
        chemicalItems.push({
          nameEn: "Urea (46% N)",
          nameHi: "यूरिया (46% नाइट्रोजन)",
          nameMr: "युरिया (४६% नत्र)",
          dose: `${Math.max(30, ureaKg)} - ${Math.max(45, ureaKg + 20)} kg / acre`,
          timingEn: isHeavyFeeder 
            ? "Split into 3 doses: 30% Basal, 35% at tillering/growth, 35% at grand growth stage."
            : "Split in 2 doses: 50% Basal at sowing and 50% Top-dressing at vegetative stage.",
          timingHi: isHeavyFeeder
            ? "3 भागों में दें: 30% बुवाई पर, 35% बढ़वार पर, और 35% मुख्य वानस्पतिक अवस्था पर।"
            : "2 भागों में दें: 50% बुवाई के समय और 50% पहली सिंचाई पर टॉप ड्रेसिंग।",
          timingMr: isHeavyFeeder
            ? "३ हप्त्यांत द्या: ३०% पेरणीवेळी, ३५% वाढीच्या काळात आणि ३५% मुख्य अवस्थेत."
            : "२ हप्त्यांत द्या: ५०% पेरणीवेळी आणि ५०% पहिल्या पाण्यावेळी वरखत.",
          tag: "Urgent",
          tagHi: "अति आवश्यक",
          tagMr: "तातडीचे"
        });
      }
    } else if (nitrogen > targetCrop.maxN) {
      chemicalItems.push({
        nameEn: "Urea (46% N)",
        nameHi: "यूरिया (46% नाइट्रोजन)",
        nameMr: "युरिया (४६% नत्र)",
        dose: "0 kg / acre (Skip Urea)",
        timingEn: `Soil nitrogen (${nitrogen} mg/kg) exceeds crop requirement (${targetCrop.maxN} mg/kg). Zero additional nitrogen needed.`,
        timingHi: `मिट्टी में नाइट्रोजन (${nitrogen} mg/kg) पर्याप्त है। यूरिया देने की बिल्कुल आवश्यकता नहीं है।`,
        timingMr: `जमिनीत नत्र (${nitrogen} mg/kg) मुबलक आहे. युरिया देण्याची अजिबात गरज नाही.`,
        tag: "Avoid",
        tagHi: "प्रयोग न करें",
        tagMr: "वापरू नका"
      });
    } else {
      // Normal maintenance dose if not legume
      if (!isLegume) {
        chemicalItems.push({
          nameEn: "Urea (46% N) - Maintenance",
          nameHi: "यूरिया (46% नत्र) - रख-रखाव",
          nameMr: "युरिया (४६% नत्र) - देखभाल डोस",
          dose: "20 - 25 kg / acre",
          timingEn: "Apply as light top-dressing during vegetative tillering.",
          timingHi: "वानस्पतिक बढ़वार के समय हल्की टॉप ड्रेसिंग के रूप में दें।",
          timingMr: "वाढीच्या अवस्थेत हलके वरखत म्हणून द्यावे.",
          tag: "Maintenance",
          tagHi: "सामान्य",
          tagMr: "देखभाल"
        });
      }
    }

    // B. PHOSPHORUS DOSING
    if (phosphorus < targetCrop.minP) {
      const deficit = targetCrop.minP - phosphorus;
      if (ph < 6.2) {
        // Acidic soil: SSP is superior
        const sspKg = Math.round(deficit * 3.5);
        chemicalItems.push({
          nameEn: "SSP (Single Super Phosphate - 16% P2O5)",
          nameHi: "एसएसपी (सिंगल सुपर फास्फेट 16% P2O5)",
          nameMr: "एसएसपी (सिंगल सुपर फॉस्फेट १६% P2O5)",
          dose: `${Math.max(60, sspKg)} - ${Math.max(80, sspKg + 25)} kg / acre`,
          timingEn: "SSP is ideal for acidic soil; also supplies 19% Calcium & 11% Sulfur to neutralize acidity and build root strength.",
          timingHi: "अम्लीय मिट्टी के लिए सर्वोत्तम; यह अम्लता घटाने हेतु 19% कैल्शियम और 11% सल्फर भी प्रदान करता है।",
          timingMr: "आम्लधर्मी जमिनीसाठी सर्वोत्तम; हे सामू सुधारण्यासाठी १९% कॅल्शियम आणि ११% गंधक पुरवते.",
          tag: "Soil-Adapted",
          tagHi: "मृदा अनुकूल",
          tagMr: "जमीन पोषक"
        });
      } else {
        const dapKg = Math.round(deficit * 1.5);
        chemicalItems.push({
          nameEn: "DAP (18:46:0) OR SSP (16% P2O5)",
          nameHi: "डीएपी (18:46:0) अथवा एसएसपी (16%)",
          nameMr: "डीएपी (१८:४६:०) किंवा एसएसपी (१६%)",
          dose: `${Math.max(30, dapKg)} kg DAP OR ${Math.max(65, Math.round(dapKg * 2.2))} kg SSP / acre`,
          timingEn: ph > 7.8 
            ? "Place 5 cm deep in seed furrow with compost to prevent alkaline calcium phosphorus fixation."
            : "Full dose as basal row placement at sowing near the root zone.",
          timingHi: ph > 7.8
            ? "क्षारीय मिट्टी में फास्फोरस जमने से रोकने हेतु 5 सेमी गहराई में कंपोस्ट के साथ दें।"
            : "बुवाई के समय कतारों में जड़ों के पास पूरी खुराक बेसल रूप में दें।",
          timingMr: ph > 7.8
            ? "चोपण जमिनीत स्फुरद अविद्राव्य होऊ नये म्हणून शेणखतात मिसळून ५ सेमी खाली द्यावे."
            : "पेरणीवेळी संपूर्ण मात्रा मुळांच्या सानिध्यात बेसल डोस म्हणून द्यावी.",
          tag: isLegume ? "Root Booster" : "Recommended",
          tagHi: isLegume ? "जड़ वर्धक" : "अनुशंसित",
          tagMr: isLegume ? "मुळे वर्धक" : "शिफारस"
        });
      }
    } else if (phosphorus > targetCrop.maxP) {
      chemicalItems.push({
        nameEn: "DAP / SSP (Phosphorus)",
        nameHi: "डीएपी / एसएसपी (फास्फोरस)",
        nameMr: "डीएपी / एसएसपी (स्फुरद)",
        dose: "0 kg / acre",
        timingEn: `High soil phosphorus (${phosphorus} mg/kg). Avoid P fertilizers to prevent induced zinc and iron deficiency.`,
        timingHi: `मिट्टी में फास्फोरस (${phosphorus} mg/kg) अधिक है। जिंक की कमी से बचने हेतु फास्फोरस खाद न दें।`,
        timingMr: `जमिनीत स्फुरद (${phosphorus} mg/kg) भरपूर आहे. जस्ताची कमतरता टाळण्यासाठी खत देणे टाळा.`,
        tag: "Avoid",
        tagHi: "प्रयोग न करें",
        tagMr: "वापरू नका"
      });
    }

    // C. POTASSIUM DOSING
    if (potassium < targetCrop.minK) {
      const deficit = targetCrop.minK - potassium;
      if (ec > 1200) {
        // High Saline soil: SOP instead of MOP
        const sopKg = Math.round(deficit * 0.9);
        chemicalItems.push({
          nameEn: "SOP (Sulfate of Potash - 0:0:50)",
          nameHi: "एसओपी (सल्फेट ऑफ पोटाश 0:0:50)",
          nameMr: "एसओपी (सल्फेट ऑफ पोटॅश ०:०:५०)",
          dose: `${Math.max(25, sopKg)} - ${Math.max(35, sopKg + 10)} kg / acre`,
          timingEn: "Chlorine-free SOP is mandatory in saline soil to prevent osmotic root tip necrosis.",
          timingHi: "खारी मिट्टी में क्लोरीन से जड़ जलने से बचाने के लिए एमओपी की जगह एसओपी जरूरी है।",
          timingMr: "क्षारयुक्त जमिनीत मुळांचे नुकसान टाळण्यासाठी क्लोरीनमुक्त एसओपी खत देणे अनिवार्य आहे.",
          tag: "Saline-Safe",
          tagHi: "लवण-सुरक्षित",
          tagMr: "क्षार-सुरक्षित"
        });
      } else {
        const mopKg = Math.round(deficit * 0.8);
        chemicalItems.push({
          nameEn: "MOP (Muriate of Potash - 60% K2O)",
          nameHi: "एमओपी (म्यूरेट ऑफ पोटाश 60%)",
          nameMr: "एमओपी (म्युरेट ऑफ पोटॅश ६०%)",
          dose: `${Math.max(20, mopKg)} - ${Math.max(30, mopKg + 10)} kg / acre`,
          timingEn: isTuberCrop
            ? "Crucial for bulb/tuber enlargement and solid weight. Apply 50% basal and 50% at tuber initiation."
            : "Apply basal dose at sowing or prior to flowering/grain filling for disease resistance.",
          timingHi: isTuberCrop
            ? "कंद व प्याज के आकार व ठोसपन के लिए अति आवश्यक। 50% बुवाई पर और 50% कंद बनते समय दें।"
            : "बुवाई पर अथवा फूल आने से पूर्व रोग प्रतिरोधक क्षमता और दाना भराव हेतु दें।",
          timingMr: isTuberCrop
            ? "कांदा व बटाटा कंद फुगवणीसाठी अत्यंत आवश्यक. ५०% पेरणीवेळी व ५०% कंद पोसताना द्यावे."
            : "रोगप्रतिकारशक्ती आणि दाणे भरण्यासाठी पेरणीवेळी किंवा फुलोऱ्यापूर्वी द्यावे.",
          tag: isTuberCrop ? "Bulb Booster" : "Yield Booster",
          tagHi: isTuberCrop ? "कंद वर्धक" : "उत्पादन वर्धक",
          tagMr: isTuberCrop ? "कंद वर्धक" : "उत्पादन वाढवणारे"
        });
      }
    } else if (potassium > targetCrop.maxK) {
      chemicalItems.push({
        nameEn: "MOP / SOP (Potassium)",
        nameHi: "एमओपी / एसओपी (पोटाश)",
        nameMr: "एमओपी / एसओपी (पालाश)",
        dose: "0 kg / acre",
        timingEn: `Ample potassium (${potassium} mg/kg) detected. Additional potash is not required.`,
        timingHi: `मिट्टी में पर्याप्त पोटाश (${potassium} mg/kg) उपलब्ध है। अतिरिक्त पोटाश की जरूरत नहीं है।`,
        timingMr: `जमिनीत मुबलक पालाश (${potassium} mg/kg) उपलब्ध आहे. अतिरिक्त पालाशची गरज नाही.`,
        tag: "Sufficient",
        tagHi: "पर्याप्त",
        tagMr: "पुरेसे"
      });
    }

    // D. SECONDARY & MICRONUTRIENT ADJUSTMENTS
    if (ph > 7.8) {
      chemicalItems.push({
        nameEn: "Zinc Sulfate (ZnSO4 21%)",
        nameHi: "जिंक सल्फेट (21%)",
        nameMr: "झिंक सल्फेट (२१%)",
        dose: "10 kg / acre (Soil) OR 0.5% foliar spray",
        timingEn: "High pH locks zinc bioavailability, causing leaf chlorosis and Khaira disease in cereals.",
        timingHi: "उच्च क्षारीयता में पौधों को जिंक नहीं मिल पाता। बुवाई पर 10 किग्रा जिंक सल्फेट जमीन में दें।",
        timingMr: "चोपण जमिनीत जस्ताची उपलब्धता कमी होते. पेरणीवेळी १० किलो झिंक सल्फेट जमिनीत द्यावे.",
        tag: "Micronutrient",
        tagHi: "सूक्ष्म पोषक",
        tagMr: "सूक्ष्म अन्नद्रव्य"
      });
    }

    if (items.length === 0 && chemicalItems.length === 0) {
      items.push({
        titleEn: "Balanced Soil Fertility Detected",
        titleHi: "संतुलित व उत्कृष्ट मृदा स्वास्थ्य",
        titleMr: "जमिनीचे आरोग्य समतोल आहे",
        actionEn: "Soil nutrients and pH are within standard target ranges. Maintain soil organic carbon with regular compost additions. Use light maintenance doses only.",
        actionHi: "मिट्टी में पोषक तत्व और पीएच संतुलित हैं। केवल सामान्य रख-रखाव खाद और नियमित देसी गोबर खाद डालें।",
        actionMr: "जमिनीतील अन्नद्रव्ये व सामू संतुलित आहे. सेंद्रिय कर्ब टिकवण्यासाठी नियमित शेणखत वापरावे."
      });
    }

    return {
      targetCrop,
      recommendations: items,
      chemicalDoses: chemicalItems
    };
  }, [sensorData, selectedFertilizerCrop, cropRecommendations, isStationOffline]);

  const speakAdvisory = () => {
    if (!("speechSynthesis" in window)) {
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    if (!sensorData || !soilAnalysis || soilAnalysis.isOfflineOrZero) {
      const waitMessage = lang === "hi" 
        ? "भूमिमित्र प्रणाली को अभी खेत से लाइव मिट्टी डेटा प्राप्त नहीं हुआ है। सभी मान शून्य हैं। कृपया सेंसर कनेक्ट होने की प्रतीक्षा करें।" 
        : lang === "mr" 
        ? "भूमिमित्र प्रणालीला अजून शेतातून थेट माती डेटा मिळालेला नाही. सर्व मूल्ये शून्य आहेत. कृपया सेन्सर जोडणीची वाट पहा."
        : "BhoomiMitra is awaiting real-time telemetry from your soil station. All parameters are set to zero. Please connect the device to hear the live report.";
      const utterance = new SpeechSynthesisUtterance(waitMessage);
      window.speechSynthesis.speak(utterance);
      return;
    }

    let speechText = "";
    if (lang === "en") {
      speechText = `BhoomiMitra Soil Health Report. Your Soil Health score is ${soilAnalysis.totalScore} out of 100, which is ${soilAnalysis.category}. Nitrogen is ${sensorData.nitrogen} milligram per kilogram, Phosphorus is ${sensorData.phosphorus}, Potassium is ${sensorData.potassium}, and pH is ${sensorData.ph}. Top suitable crops are ${cropRecommendations.slice(0, 3).map(c => c.displayName).join(", ")}. ${t.irrigation[soilAnalysis.mStatus]}`;
    } else if (lang === "hi") {
      speechText = `भूमिमित्र मृदा रिपोर्ट। आपकी मिट्टी का स्वास्थ्य स्कोर 100 में से ${soilAnalysis.totalScore} है। नाइट्रोजन ${sensorData.nitrogen}, फास्फोरस ${sensorData.phosphorus}, और पोटाश ${sensorData.potassium} है। मिट्टी का पीएच ${sensorData.ph} है। आपकी मिट्टी के लिए सबसे उपयुक्त फसलें हैं: ${cropRecommendations.slice(0, 3).map(c => c.displayName).join(", ")}। सिंचाई सलाह: ${t.irrigation[soilAnalysis.mStatus]}`;
    } else if (lang === "mr") {
      speechText = `भूमिमित्र माती आरोग्य अहवाल। आपल्या जमिनीचा आरोग्य गुण 100 पैकी ${soilAnalysis.totalScore} आहे। नत्र ${sensorData.nitrogen}, स्फुरद ${sensorData.phosphorus}, पालाश ${sensorData.potassium} आणि जमिनीचा सामू ${sensorData.ph} आहे। आपल्या शेतासाठी सर्वात अनुकूल पिके आहेत: ${cropRecommendations.slice(0, 3).map(c => c.displayName).join(", ")}। पाणी सल्ला: ${t.irrigation[soilAnalysis.mStatus]}`;
    }

    const utterance = new SpeechSynthesisUtterance(speechText);
    utterance.rate = 0.92;
    utterance.pitch = 1.0;

    // Pick appropriate voice if available
    const voices = window.speechSynthesis.getVoices();
    if (lang === "hi") {
      const hiVoice = voices.find(v => v.lang.includes("hi") || v.name.includes("Hindi"));
      if (hiVoice) utterance.voice = hiVoice;
    } else if (lang === "mr") {
      const mrVoice = voices.find(v => v.lang.includes("mr") || v.lang.includes("hi"));
      if (mrVoice) utterance.voice = mrVoice;
    }

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const getBadgeClass = (status) => {
    switch (status) {
      case "optimal":
      case "neutral":
      case "normal":
      case "excellent":
      case "good":
      case "lowSaline":
        return "bg-emerald-100 text-emerald-800 border-emerald-300";
      case "low":
      case "dry":
      case "acidic":
      case "cold":
      case "moderate":
      case "medSaline":
        return "bg-amber-100 text-amber-800 border-amber-300";
      case "high":
      case "wet":
      case "alkaline":
      case "hot":
      case "poor":
      case "critical":
      case "highSaline":
        return "bg-rose-100 text-rose-800 border-rose-300";
      default:
        return "bg-slate-100 text-slate-700 border-slate-300";
    }
  };

  const getStatusTextClass = (status) => {
    switch (status) {
      case "optimal":
      case "neutral":
      case "normal":
      case "lowSaline":
        return "text-emerald-700 font-bold";
      case "low":
      case "dry":
      case "acidic":
      case "cold":
      case "medSaline":
        return "text-amber-700 font-bold";
      case "high":
      case "wet":
      case "alkaline":
      case "hot":
      case "highSaline":
        return "text-rose-700 font-bold";
      default:
        return "text-slate-500 font-medium";
    }
  };

  const getScoreColor = (score) => {
    if (score >= 80) return "text-emerald-600 stroke-emerald-500";
    if (score >= 60) return "text-lime-600 stroke-lime-500";
    if (score >= 45) return "text-amber-500 stroke-amber-500";
    return "text-rose-600 stroke-rose-500";
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans pb-16 antialiased selection:bg-emerald-200">
      {/* Top Banner & Language Bar */}
      <header className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 text-white shadow-md sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-600/60 rounded-xl border border-emerald-400/40 shadow-inner flex items-center justify-center">
              <Sprout className="w-7 h-7 text-emerald-200" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl md:text-2xl font-bold tracking-tight text-white flex items-center gap-1.5">
                  {t.appTitle}
                </h1>
                <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/40 border border-emerald-300/40 text-emerald-100 hidden sm:inline-block">
                  {lang === "hi" ? "स्मार्ट खेत प्रणाली" : lang === "mr" ? "स्मार्ट शेत प्रणाली" : "Smart Farm Ready"}
                </span>
              </div>
              <p className="text-xs text-emerald-100/90 font-medium">
                {t.tagline}
              </p>
            </div>
          </div>

          {/* Controls: Take Reading + Audio speech + Language Selector + Connection pill */}
          <div className="flex items-center flex-wrap gap-2.5">
            {/* Direct ESP32 Reading Trigger Button */}
            <button
              onClick={() => takeReadingFromEsp32(true)}
              disabled={isTakingReading}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs md:text-sm font-bold transition shadow-sm ${
                isTakingReading
                  ? "bg-amber-500 text-white animate-pulse"
                  : "bg-emerald-500 hover:bg-emerald-400 text-white border border-emerald-300/40"
              }`}
              title={t.liveSync.takeReading}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTakingReading ? "animate-spin" : ""}`} />
              <span>{isTakingReading ? t.liveSync.readingNow : t.liveSync.takeReading}</span>
            </button>

            {/* Audio Readout Button */}
            <button
              onClick={speakAdvisory}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs md:text-sm font-semibold transition shadow-sm ${
                isSpeaking
                  ? "bg-amber-500 text-white animate-pulse"
                  : "bg-white/15 hover:bg-white/25 text-white border border-white/20"
              }`}
              title={t.voiceGuidance}
            >
              {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-emerald-200" />}
              <span>{isSpeaking ? t.stopAudio : t.voiceGuidance}</span>
            </button>

            {/* Language Switcher */}
            <div className="flex bg-emerald-900/60 p-1 rounded-lg border border-emerald-600/60 text-xs font-semibold">
              <button
                onClick={() => setLang("en")}
                className={`px-2.5 py-1 rounded-md transition ${lang === "en" ? "bg-white text-emerald-900 shadow-sm" : "text-emerald-200 hover:text-white"}`}
              >
                English
              </button>
              <button
                onClick={() => setLang("hi")}
                className={`px-2.5 py-1 rounded-md transition ${lang === "hi" ? "bg-white text-emerald-900 shadow-sm" : "text-emerald-200 hover:text-white"}`}
              >
                हिंदी
              </button>
              <button
                onClick={() => setLang("mr")}
                className={`px-2.5 py-1 rounded-md transition ${lang === "mr" ? "bg-white text-emerald-900 shadow-sm" : "text-emerald-200 hover:text-white"}`}
              >
                मराठी
              </button>
            </div>

            {/* Hardware Live Indicator */}
            <button
              onClick={() => setShowConfigModal(true)}
              className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-black/25 hover:bg-black/35 border border-emerald-500/30 text-xs text-emerald-200 transition"
              title={t.configModal.title}
            >
              <span className={`w-2 h-2 rounded-full ${hardwareConnected ? "bg-emerald-400 animate-ping" : "bg-rose-400"}`}></span>
              <span className="hidden sm:inline font-mono">
                {hardwareConnected
                  ? (lang === "hi" ? "ESP32 कनेक्टेड" : lang === "mr" ? "ESP32 कनेक्टेड" : "ESP32 ONLINE")
                  : (lang === "hi" ? "ऑफलाइन" : lang === "mr" ? "ऑफलाइन" : "OFFLINE")}
              </span>
              <Settings2 className="w-3.5 h-3.5 opacity-80" />
            </button>
          </div>
        </div>
      </header>

      {}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-5">
        {/* Navigation tabs */}
        <div className="flex border-b border-slate-200 gap-2 overflow-x-auto scrollbar-none pb-1">
          <button
            onClick={() => setActiveTab("overview")}
            className={`flex items-center space-x-2 py-2.5 px-4 font-semibold text-sm border-b-2 whitespace-nowrap transition ${
              activeTab === "overview"
                ? "border-emerald-600 text-emerald-700 bg-emerald-50/60 rounded-t-lg"
                : "border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300"
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>{t.tabs.overview}</span>
          </button>

          <button
            onClick={() => setActiveTab("crops")}
            className={`flex items-center space-x-2 py-2.5 px-4 font-semibold text-sm border-b-2 whitespace-nowrap transition ${
              activeTab === "crops"
                ? "border-emerald-600 text-emerald-700 bg-emerald-50/60 rounded-t-lg"
                : "border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300"
            }`}
          >
            <Sprout className="w-4 h-4" />
            <span>{t.tabs.crops}</span>
            <span className="ml-1 px-1.5 py-0.2 text-[11px] font-bold rounded-full bg-emerald-200 text-emerald-800">
              {cropRecommendations.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab("fertilizer")}
            className={`flex items-center space-x-2 py-2.5 px-4 font-semibold text-sm border-b-2 whitespace-nowrap transition ${
              activeTab === "fertilizer"
                ? "border-emerald-600 text-emerald-700 bg-emerald-50/60 rounded-t-lg"
                : "border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300"
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>{t.tabs.fertilizer}</span>
          </button>

          <button
            onClick={() => setActiveTab("healthCard")}
            className={`flex items-center space-x-2 py-2.5 px-4 font-semibold text-sm border-b-2 whitespace-nowrap transition ${
              activeTab === "healthCard"
                ? "border-emerald-600 text-emerald-700 bg-emerald-50/60 rounded-t-lg"
                : "border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300"
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>{t.tabs.healthCard}</span>
          </button>
        </div>

        {/* ESP32 Direct Telemetry Status Banner */}
        <div className="mt-3 flex flex-wrap items-center justify-between text-xs text-slate-500 bg-slate-100/90 px-3 py-2 rounded-lg border border-slate-200">
          <div className="flex items-center space-x-2">
            <Radio className={`w-3.5 h-3.5 ${hardwareConnected ? "text-emerald-600 animate-pulse" : "text-rose-500 animate-pulse"}`} />
            <span>
              <span className="font-semibold text-slate-700">{hardwareConnected ? t.liveSync.active : (lang === "hi" ? "ESP32 डिस्कनेक्टेड" : lang === "mr" ? "ESP32 डिस्कनेक्टेड" : "Station Disconnected")}</span> • <span className="font-mono text-emerald-800 inline-flex items-center"><Wifi className="w-3.5 h-3.5 inline mr-1 text-emerald-700" />IP: {espIp}</span> {usbConnected && <span className="ml-1 px-1.5 py-0.2 rounded bg-blue-100 text-blue-800 font-bold">USB</span>}
            </span>
          </div>
          <div className="flex items-center space-x-3 mt-1 sm:mt-0 flex-wrap gap-y-1">
            <span>{t.liveSync.lastReading}: <span className="font-mono text-slate-700 font-semibold">{lastReadingTime || t.liveSync.awaiting}</span></span>
            <button
              onClick={() => takeReadingFromEsp32(true)}
              disabled={isTakingReading}
              title={t.liveSync.takeReading}
              className="text-emerald-700 hover:text-emerald-900 font-bold underline flex items-center gap-1"
            >
              <RefreshCw className={`w-3 h-3 ${isTakingReading ? "animate-spin" : ""}`} />
              <span>{isTakingReading ? t.liveSync.readingNow : t.liveSync.syncCloud}</span>
            </button>
            {isWebSerialSupported && (
              <button
                onClick={connectUsbSerial}
                className={`font-semibold underline flex items-center gap-1 ${usbConnected ? "text-blue-700" : "text-slate-600 hover:text-slate-900"}`}
                title="Connect directly via USB Cable"
              >
                <Usb className="w-3 h-3" />
                <span>{usbConnected ? t.liveSync.usbDisconnect : t.liveSync.usbConnect}</span>
              </button>
            )}
            <label className="flex items-center gap-1.5 cursor-pointer text-slate-600 select-none">
              <input
                type="checkbox"
                checked={autoRefresh}
                onChange={(e) => setAutoRefresh(e.target.checked)}
                className="rounded text-emerald-600 focus:ring-emerald-500 h-3.5 w-3.5"
              />
              <span className="text-[11px] font-medium">{t.liveSync.autoPolling}</span>
            </label>
          </div>
        </div>

        {/* Informational Banner when waiting for real sensor data */}
        {(isStationOffline || !sensorData || soilAnalysis?.isOfflineOrZero) && (
          <div className="mt-4 bg-amber-50/90 border border-amber-200/90 rounded-2xl p-4 flex items-start gap-3.5 shadow-sm">
            <div className="p-2 rounded-xl bg-amber-100 text-amber-700 flex-shrink-0 mt-0.5">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div className="flex-1 text-xs">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-amber-900 text-sm">
                  {isStationOffline
                    ? (lang === "hi" ? "ESP32 स्टेशन से कनेक्ट करें" : lang === "mr" ? "ESP32 स्टेशनशी जोडा" : "Connect to ESP32 Soil Station")
                    : t.liveSync.awaitingTitle}
                </h4>
                <span className="px-2 py-0.5 rounded-full bg-rose-200/80 text-rose-800 text-[10px] font-bold">
                  {isStationOffline ? "OFFLINE" : t.scoreBands.awaitingBadge}
                </span>
              </div>
              <p className="text-amber-800/90 mt-1 leading-relaxed">
                {lang === "hi"
                  ? "यह ऐप केवल ESP32 और भौतिक सेंसरों से प्राप्त वास्तविक रीडिंग प्रदर्शित करता है। कोई बनावटी NPK मान नहीं दिखाया जाता है। 'रीडिंग लें' बटन दबाकर सीधे ESP32 से ताजा डेटा प्राप्त करें।"
                  : lang === "mr"
                  ? "हे ॲप केवळ ESP32 आणि भौतिक सेन्सरकडून मिळालेली खरी रीडिंग दाखवते. कोणतेही अंदाजे NPK मूल्य दाखवले जात नाही. 'रीडिंग घ्या' बटण दाबून थेट ESP32 कडून डेटा मिळवा."
                  : "This application takes readings directly from your ESP32 hardware with zero cloud intermediary. No artificial or estimated NPK values are generated. Click 'Take Reading from ESP32' to sample the physical sensors in real time."}
              </p>
              {sensorStatus.errorMessage && (
                <p className="text-rose-700 font-semibold mt-1 bg-rose-50 p-2 rounded border border-rose-200">
                  ⚠️ {sensorStatus.errorMessage}
                </p>
              )}
              <div className="mt-2.5 flex items-center gap-3">
                <button
                  onClick={() => takeReadingFromEsp32(true)}
                  disabled={isTakingReading}
                  className="px-3.5 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition shadow-sm"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTakingReading ? "animate-spin" : ""}`} />
                  <span>{isTakingReading ? t.liveSync.readingNow : t.liveSync.checkNow}</span>
                </button>
                {isWebSerialSupported && (
                  <button
                    onClick={connectUsbSerial}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-xs flex items-center gap-1.5 transition"
                  >
                    <Usb className="w-3.5 h-3.5" />
                    <span>{usbConnected ? t.liveSync.usbDisconnect : t.liveSync.usbConnect}</span>
                  </button>
                )}
                <button
                  onClick={() => setShowConfigModal(true)}
                  className="text-emerald-800 underline font-semibold text-xs"
                >
                  {t.configModal.title}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 1: Overview Tab */}
        {activeTab === "overview" && (
          <div className="mt-6 space-y-6">
            {/* Top Row: Overall Score & Irrigation Alert */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Soil Health Score Gauge Card */}
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200/80 flex flex-col justify-between relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-bl-full -z-0 pointer-events-none opacity-60"></div>
                <div className="z-10">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      {t.overallScore}
                    </span>
                    <span className={`px-2.5 py-1 text-xs font-bold rounded-full border ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getBadgeClass(soilAnalysis.category === "excellent" || soilAnalysis.category === "good" ? "optimal" : "low") : "bg-slate-100 text-slate-500 border-slate-200"}`}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.scoreRemarks[soilAnalysis.category] : t.scoreBands.awaitingBadge}
                    </span>
                  </div>

                  <div className="mt-4 flex items-center justify-center space-x-6">
                    {/* Radial Progress Ring */}
                    <div className="relative w-32 h-32 flex items-center justify-center">
                      <svg className="w-32 h-32 transform -rotate-90">
                        <circle
                          cx="64"
                          cy="64"
                          r="52"
                          stroke="currentColor"
                          strokeWidth="10"
                          className="text-slate-100"
                          fill="transparent"
                        />
                        <circle
                          cx="64"
                          cy="64"
                          r="52"
                          stroke="currentColor"
                          strokeWidth="10"
                          strokeDasharray={326.7}
                          strokeDashoffset={soilAnalysis && !soilAnalysis.isOfflineOrZero ? 326.7 - (326.7 * soilAnalysis.totalScore) / 100 : 326.7}
                          strokeLinecap="round"
                          className={`transition-all duration-1000 ease-out ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getScoreColor(soilAnalysis.totalScore) : "text-slate-200"}`}
                          fill="transparent"
                        />
                      </svg>
                      <div className="absolute flex flex-col items-center justify-center text-center">
                        <span className="text-3xl font-black text-slate-800 tracking-tight">
                          {soilAnalysis ? soilAnalysis.totalScore : 0}
                        </span>
                        <span className="text-[10px] uppercase font-bold text-slate-400">/ 100</span>
                      </div>
                    </div>

                    <div className="space-y-1.5 text-xs text-slate-600">
                      <div className="flex items-center space-x-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                        <span>{t.scoreBands.optimal}</span>
                      </div>
                      <div className="flex items-center space-x-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-lime-500"></span>
                        <span>{t.scoreBands.moderate}</span>
                      </div>
                      <div className="flex items-center space-x-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                        <span>{t.scoreBands.low}</span>
                      </div>
                      <div className="flex items-center space-x-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                        <span>{t.scoreBands.critical}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 text-xs text-slate-500 flex justify-between items-center z-10">
                  <span>{t.scoreBands.qualityIndex}</span>
                  <button
                    onClick={() => setActiveTab("fertilizer")}
                    className="text-emerald-700 font-semibold hover:underline flex items-center gap-1"
                  >
                    <span>{t.scoreBands.viewActions}</span> <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Water & Irrigation Status Card */}
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200/80 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="p-2 rounded-lg bg-blue-50 text-blue-600 border border-blue-100">
                        <Droplets className="w-5 h-5" />
                      </div>
                      <h3 className="font-bold text-slate-800 text-base">{t.fertilizerSection.irrigationAlert}</h3>
                    </div>
                    <span className={`px-2.5 py-0.5 text-xs font-bold rounded-full border ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getBadgeClass(soilAnalysis.mStatus) : "bg-slate-100 text-slate-500 border-slate-200"}`}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.mStatus] : t.measurements.pending}
                    </span>
                  </div>

                  <p className="mt-4 text-sm text-slate-600 leading-relaxed bg-blue-50/60 p-3.5 rounded-xl border border-blue-100/70">
                    {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.irrigation[soilAnalysis.mStatus] : (lang === "hi" ? "सेंसर से मिट्टी का डेटा प्राप्त होते ही सिंचाई सलाह यहाँ दिखाई देगी।" : lang === "mr" ? "सेन्सरकडून मातीचा डेटा मिळताच पाणी व्यवस्थापन सल्ला येथे दिसेल." : "Soil moisture and temperature readings will appear here once received.")}
                  </p>

                  <div className="mt-4 grid grid-cols-2 gap-3 text-center">
                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <span className="text-xs text-slate-500 block">{t.irrigationCard.moistureLabel}</span>
                      <span className="text-lg font-bold text-slate-800">{sensorData ? `${sensorData.moisture}%` : "0%"}</span>
                    </div>
                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <span className="text-xs text-slate-500 block">{t.irrigationCard.tempLabel}</span>
                      <span className="text-lg font-bold text-slate-800">{sensorData ? `${sensorData.temperature}°C` : "0°C"}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                  <span>{t.irrigationCard.footerLeft}</span>
                  <span className="font-medium text-emerald-700">{t.irrigationCard.footerRight}</span>
                </div>
              </div>

              {/* Top Crop Recommendation Snapshot */}
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200/80 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-100">
                        <Sprout className="w-5 h-5" />
                      </div>
                      <h3 className="font-bold text-slate-800 text-base">{t.cropSection.title}</h3>
                    </div>
                    <span className="text-xs font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
                      {t.cropsSnapshot.bestThree}
                    </span>
                  </div>

                  <div className="mt-3 divide-y divide-slate-100">
                    {cropRecommendations.length > 0 ? (
                      cropRecommendations.slice(0, 3).map((crop) => (
                        <div key={crop.id} className="py-2.5 flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <span className="text-2xl">{crop.icon}</span>
                            <div>
                              <span className="text-sm font-bold text-slate-800 block">{crop.displayName}</span>
                              <span className="text-xs text-slate-500">{t.seasons[crop.season] || crop.season}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className={`text-sm font-black ${crop.matchScore >= 80 ? "text-emerald-700" : crop.matchScore >= 60 ? "text-lime-700" : crop.matchScore >= 45 ? "text-amber-600" : "text-rose-600"}`}>
                              {crop.matchScore}%
                            </span>
                            <span className="text-[10px] text-slate-400 block">{t.cropsSnapshot.suitability}</span>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="py-6 text-center text-slate-400">
                        <Sprout className="w-6 h-6 mx-auto mb-1 text-slate-300" />
                        <p className="text-xs font-semibold text-slate-600">{t.cropsSnapshot.awaitingTitle}</p>
                        <p className="text-[11px] text-slate-400">{t.cropsSnapshot.awaitingDesc}</p>
                      </div>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => setActiveTab("crops")}
                  className="mt-3 w-full py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-semibold text-xs rounded-xl border border-emerald-200/70 transition flex items-center justify-center gap-1.5"
                >
                  <span>{t.cropsSnapshot.viewAll}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Parameter Cards Grid (7 Parameters: N, P, K, pH, Moisture, Temp, EC) */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                  <Activity className="w-5 h-5 text-emerald-600" />
                  <span>{t.measurements.heading}</span>
                </h2>
                <button
                  onClick={() => setShowConfigModal(true)}
                  className="text-xs font-medium text-slate-500 hover:text-emerald-700 flex items-center gap-1"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>{t.measurements.manualBtn}</span>
                </button>
              </div>

              {/* Physical Sensor Telemetry Diagnostics - True Sensor Guarantee */}
              <div className="mb-5 p-4 bg-white rounded-xl border border-slate-200 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-3 border-b border-slate-100 gap-2">
                  <div className="flex items-center space-x-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-600" />
                    <div>
                      <h4 className="font-bold text-slate-800 text-sm">
                        {lang === "hi" ? "भौतिक सेंसर सत्यापन (सीधा ESP32)" : lang === "mr" ? "भौतिक सेन्सर पडताळणी (थेट ESP32)" : "Physical Sensor Telemetry (ESP32 Direct)"}
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        {lang === "hi" ? "100% वास्तविक सेंसर रीडिंग। कोई भी बनावटी या AI-अनुमानित मान नहीं।" : lang === "mr" ? "१००% खरी सेन्सर रीडिंग. कोणतेही बनावट किंवा AI-अंदाजे मूल्य नाही." : "100% Genuine Sensor Telemetry. Zero artificial estimation or simulated values."}
                      </p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 self-start sm:self-auto">
                    {lang === "hi" ? "सत्य सेंसर मोड" : lang === "mr" ? "सत्य सेन्सर मोड" : "True Sensor Mode"}
                  </span>
                </div>

                <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                  {/* NPK RS485 Modbus Probe */}
                  <div className={`p-3 rounded-lg border flex items-start space-x-2.5 ${sensorStatus.npkConnected ? "bg-emerald-50/70 border-emerald-200 text-emerald-900" : "bg-amber-50/70 border-amber-200 text-amber-900"}`}>
                    <Layers className={`w-4 h-4 flex-shrink-0 mt-0.5 ${sensorStatus.npkConnected ? "text-emerald-600" : "text-amber-600"}`} />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold">RS485 NPK Probe</span>
                        <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${sensorStatus.npkConnected ? "bg-emerald-200 text-emerald-800" : "bg-amber-200 text-amber-800"}`}>
                          {sensorStatus.npkConnected ? "VERIFIED" : "SILENT (0)"}
                        </span>
                      </div>
                      <p className="text-[11px] mt-1 leading-tight text-slate-600">
                        {sensorStatus.npkConnected
                          ? `Active & True: N=${sensorData.nitrogen}, P=${sensorData.phosphorus}, K=${sensorData.potassium} mg/kg`
                          : "No signal received from Modbus probe. Displaying true 0 mg/kg (No artificial data). Check 12V DC power."}
                      </p>
                    </div>
                  </div>

                  {/* DS18B20 Temp Probe */}
                  <div className={`p-3 rounded-lg border flex items-start space-x-2.5 ${sensorStatus.tempConnected ? "bg-emerald-50/70 border-emerald-200 text-emerald-900" : "bg-slate-50 border-slate-200 text-slate-700"}`}>
                    <Thermometer className={`w-4 h-4 flex-shrink-0 mt-0.5 ${sensorStatus.tempConnected ? "text-emerald-600" : "text-slate-400"}`} />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold">Soil Temp (DS18B20)</span>
                        <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${sensorStatus.tempConnected ? "bg-emerald-200 text-emerald-800" : "bg-slate-200 text-slate-700"}`}>
                          {sensorStatus.tempConnected ? "ACTIVE" : "STANDBY"}
                        </span>
                      </div>
                      <p className="text-[11px] mt-1 leading-tight text-slate-600">
                        {sensorStatus.tempConnected ? `True Reading: ${sensorData.temperature} °C` : "Digital sensor standby or disconnected"}
                      </p>
                    </div>
                  </div>

                  {/* Capacitive Moisture Probe */}
                  <div className={`p-3 rounded-lg border flex items-start space-x-2.5 ${sensorStatus.moistureConnected ? "bg-emerald-50/70 border-emerald-200 text-emerald-900" : "bg-slate-50 border-slate-200 text-slate-700"}`}>
                    <Droplets className={`w-4 h-4 flex-shrink-0 mt-0.5 ${sensorStatus.moistureConnected ? "text-emerald-600" : "text-slate-400"}`} />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold">Capacitive Moisture</span>
                        <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${sensorStatus.moistureConnected ? "bg-emerald-200 text-emerald-800" : "bg-slate-200 text-slate-700"}`}>
                          {sensorStatus.moistureConnected ? "ACTIVE" : "STANDBY"}
                        </span>
                      </div>
                      <p className="text-[11px] mt-1 leading-tight text-slate-600">
                        {sensorStatus.moistureConnected ? `True Reading: ${sensorData.moisture} %` : "Dielectric sensor dry or disconnected"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Nitrogen */}
                <div className="bg-white rounded-xl p-4 shadow-sm border border-slate-200/80 hover:border-emerald-300 transition group">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase">{t.parameters.n.label}</span>
                    <span className={`px-2 py-0.5 text-xs font-bold rounded-md border ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getBadgeClass(soilAnalysis.nStatus) : "bg-slate-100 text-slate-500 border-slate-200"}`}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.nStatus] : t.measurements.pending}
                    </span>
                  </div>
                  <div className="mt-3 flex items-baseline space-x-1.5">
                    <span className="text-3xl font-extrabold text-slate-900 group-hover:text-emerald-700 transition">
                      {sensorData ? sensorData.nitrogen : 0}
                    </span>
                    <span className="text-xs text-slate-500 font-medium">{t.parameters.n.unit}</span>
                  </div>
                  <div className="mt-3 text-xs text-slate-500 border-t border-slate-100 pt-2 flex items-center justify-between">
                    <span>{t.measurements.target}: 100 - 220 {t.parameters.n.unit}</span>
                    <span className={soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.nStatus) : "text-slate-400 font-medium"}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.nStatus] : "--"}
                    </span>
                  </div>
                </div>

                {/* Phosphorus */}
                <div className="bg-white rounded-xl p-4 shadow-sm border border-slate-200/80 hover:border-emerald-300 transition group">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase">{t.parameters.p.label}</span>
                    <span className={`px-2 py-0.5 text-xs font-bold rounded-md border ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getBadgeClass(soilAnalysis.pStatus) : "bg-slate-100 text-slate-500 border-slate-200"}`}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.pStatus] : t.measurements.pending}
                    </span>
                  </div>
                  <div className="mt-3 flex items-baseline space-x-1.5">
                    <span className="text-3xl font-extrabold text-slate-900 group-hover:text-emerald-700 transition">
                      {sensorData ? sensorData.phosphorus : 0}
                    </span>
                    <span className="text-xs text-slate-500 font-medium">{t.parameters.p.unit}</span>
                  </div>
                  <div className="mt-3 text-xs text-slate-500 border-t border-slate-100 pt-2 flex items-center justify-between">
                    <span>{t.measurements.target}: 25 - 60 {t.parameters.p.unit}</span>
                    <span className={soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.pStatus) : "text-slate-400 font-medium"}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.pStatus] : "--"}
                    </span>
                  </div>
                </div>

                {/* Potassium */}
                <div className="bg-white rounded-xl p-4 shadow-sm border border-slate-200/80 hover:border-emerald-300 transition group">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase">{t.parameters.k.label}</span>
                    <span className={`px-2 py-0.5 text-xs font-bold rounded-md border ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getBadgeClass(soilAnalysis.kStatus) : "bg-slate-100 text-slate-500 border-slate-200"}`}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.kStatus] : t.measurements.pending}
                    </span>
                  </div>
                  <div className="mt-3 flex items-baseline space-x-1.5">
                    <span className="text-3xl font-extrabold text-slate-900 group-hover:text-emerald-700 transition">
                      {sensorData ? sensorData.potassium : 0}
                    </span>
                    <span className="text-xs text-slate-500 font-medium">{t.parameters.k.unit}</span>
                  </div>
                  <div className="mt-3 text-xs text-slate-500 border-t border-slate-100 pt-2 flex items-center justify-between">
                    <span>{t.measurements.target}: 120 - 250 {t.parameters.k.unit}</span>
                    <span className={soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.kStatus) : "text-slate-400 font-medium"}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.kStatus] : "--"}
                    </span>
                  </div>
                </div>

                {/* pH */}
                <div className="bg-white rounded-xl p-4 shadow-sm border border-slate-200/80 hover:border-emerald-300 transition group">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase">{t.parameters.ph.label}</span>
                    <span className={`px-2 py-0.5 text-xs font-bold rounded-md border ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getBadgeClass(soilAnalysis.phStatus) : "bg-slate-100 text-slate-500 border-slate-200"}`}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.phStatus] : t.measurements.pending}
                    </span>
                  </div>
                  <div className="mt-3 flex items-baseline space-x-1.5">
                    <span className="text-3xl font-extrabold text-slate-900 group-hover:text-emerald-700 transition">
                      {sensorData ? sensorData.ph : 0}
                    </span>
                    <span className="text-xs text-slate-500 font-medium">{t.parameters.ph.unit}</span>
                  </div>
                  <div className="mt-3 text-xs text-slate-500 border-t border-slate-100 pt-2 flex items-center justify-between">
                    <span>{t.measurements.target}: 6.2 - 7.5</span>
                    <span className={soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.phStatus) : "text-slate-400 font-medium"}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.phStatus] : "--"}
                    </span>
                  </div>
                </div>

                {/* Moisture */}
                <div className="bg-white rounded-xl p-4 shadow-sm border border-slate-200/80 hover:border-emerald-300 transition group">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase">{t.parameters.moisture.label}</span>
                    <span className={`px-2 py-0.5 text-xs font-bold rounded-md border ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getBadgeClass(soilAnalysis.mStatus) : "bg-slate-100 text-slate-500 border-slate-200"}`}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.mStatus] : t.measurements.pending}
                    </span>
                  </div>
                  <div className="mt-3 flex items-baseline space-x-1.5">
                    <span className="text-3xl font-extrabold text-slate-900 group-hover:text-emerald-700 transition">
                      {sensorData ? sensorData.moisture : 0}
                    </span>
                    <span className="text-xs text-slate-500 font-medium">{t.parameters.moisture.unit}</span>
                  </div>
                  <div className="mt-3 text-xs text-slate-500 border-t border-slate-100 pt-2 flex items-center justify-between">
                    <span>{t.measurements.target}: 35% - 60%</span>
                    <span className={soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.mStatus) : "text-slate-400 font-medium"}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.mStatus] : "--"}
                    </span>
                  </div>
                </div>

                {/* Soil Temperature */}
                <div className="bg-white rounded-xl p-4 shadow-sm border border-slate-200/80 hover:border-emerald-300 transition group">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase">{t.parameters.temp.label}</span>
                    <span className={`px-2 py-0.5 text-xs font-bold rounded-md border ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getBadgeClass(soilAnalysis.tempStatus) : "bg-slate-100 text-slate-500 border-slate-200"}`}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.tempStatus] : t.measurements.pending}
                    </span>
                  </div>
                  <div className="mt-3 flex items-baseline space-x-1.5">
                    <span className="text-3xl font-extrabold text-slate-900 group-hover:text-emerald-700 transition">
                      {sensorData ? sensorData.temperature : 0}
                    </span>
                    <span className="text-xs text-slate-500 font-medium">{t.parameters.temp.unit}</span>
                  </div>
                  <div className="mt-3 text-xs text-slate-500 border-t border-slate-100 pt-2 flex items-center justify-between">
                    <span>{t.measurements.target}: 18 - 32 °C</span>
                    <span className={soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.tempStatus) : "text-slate-400 font-medium"}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.tempStatus] : "--"}
                    </span>
                  </div>
                </div>

                {/* EC Salinity */}
                <div className="bg-white rounded-xl p-4 shadow-sm border border-slate-200/80 hover:border-emerald-300 transition group">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 uppercase">{t.parameters.ec.label}</span>
                    <span className={`px-2 py-0.5 text-xs font-bold rounded-md border ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getBadgeClass(soilAnalysis.ecStatus) : "bg-slate-100 text-slate-500 border-slate-200"}`}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.ecStatus] : t.measurements.pending}
                    </span>
                  </div>
                  <div className="mt-3 flex items-baseline space-x-1.5">
                    <span className="text-3xl font-extrabold text-slate-900 group-hover:text-emerald-700 transition">
                      {sensorData ? sensorData.ec : 0}
                    </span>
                    <span className="text-xs text-slate-500 font-medium">{t.parameters.ec.unit}</span>
                  </div>
                  <div className="mt-3 text-xs text-slate-500 border-t border-slate-100 pt-2 flex items-center justify-between">
                    <span>{t.measurements.target}: &lt; 1000 {t.parameters.ec.unit}</span>
                    <span className={soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.ecStatus) : "text-slate-400 font-medium"}>
                      {soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.ecStatus] : "--"}
                    </span>
                  </div>
                </div>

                {/* Quick Calibration / Slider Trigger Card */}
                <div
                  onClick={() => setShowConfigModal(true)}
                  className="bg-gradient-to-br from-emerald-500 to-teal-700 rounded-xl p-4 text-white shadow-sm cursor-pointer hover:shadow-md transition flex flex-col justify-between"
                >
                  <div>
                    <Sliders className="w-6 h-6 text-emerald-200 mb-2" />
                    <h3 className="font-bold text-base leading-tight">{t.tuningCard.title}</h3>
                    <p className="text-xs text-emerald-100/90 mt-1">
                      {t.tuningCard.desc}
                    </p>
                  </div>
                  <div className="mt-3 flex items-center justify-between text-xs font-semibold pt-2 border-t border-white/20">
                    <span>{t.tuningCard.openBtn}</span>
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {}
        {/* TAB 2: Crop Recommendations */}
        {activeTab === "crops" && (
          <div className="mt-6 space-y-6">
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
                <div>
                  <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                    <Sprout className="w-6 h-6 text-emerald-600" />
                    <span>{t.cropSection.title}</span>
                  </h2>
                  <p className="text-sm text-slate-500 mt-1">
                    {t.cropSection.subtitle}
                  </p>
                </div>
                <div className="flex items-center space-x-2 bg-emerald-50 text-emerald-800 px-3.5 py-1.5 rounded-xl border border-emerald-200 text-xs font-semibold">
                  <TrendingUp className="w-4 h-4" />
                  <span>{t.cropTab.badge}</span>
                </div>
              </div>

              {/* Crop Cards Grid */}
              {cropRecommendations.length === 0 ? (
                <div className="bg-slate-50 rounded-2xl p-12 text-center border border-slate-200 mt-6">
                  <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
                    <Sprout className="w-7 h-7 text-emerald-700 animate-pulse" />
                  </div>
                  <h3 className="font-bold text-slate-800 text-base">{t.cropTab.awaitingTitle}</h3>
                  <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
                    {t.cropTab.awaitingDesc}
                  </p>
                  <button
                    onClick={() => takeReadingFromEsp32(true)}
                    className="mt-4 px-4 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 transition"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>{t.cropTab.takeReading}</span>
                  </button>
                </div>
              ) : (
                <>
                  {sensorData && sensorData.nitrogen === 0 && sensorData.phosphorus === 0 && sensorData.potassium === 0 && (
                    <div className="mt-4 p-4 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                      <div className="text-xs">
                        <h4 className="font-bold text-amber-900">
                          {lang === "hi"
                            ? "चेतावनी: N-P-K मान 0 mg/kg हैं (पोषक तत्वों का भारी अभाव)"
                            : lang === "mr"
                            ? "सूचना: मातीत N-P-K चे प्रमाण 0 mg/kg आहे (अन्नद्रव्यांची अत्यंत कमतरता)"
                            : "Notice: N-P-K Readings are 0 mg/kg (Zero Macronutrients Detected)"}
                        </h4>
                        <p className="mt-1 leading-relaxed text-amber-800">
                          {lang === "hi"
                            ? "मिट्टी में नाइट्रोजन, फास्फोरस व पोटाश शून्य होने के कारण फसल उपयुक्तता 15% (अनुपयुक्त) हो गई है। बिना खाद के फसलें विकसित नहीं हो सकती हैं। 'खाद एवं उपचार' टैब में सुझाई गई खुराक तुरंत डालें। (यदि आपका RS485 NPK सेंसर नया लगा है, तो उसकी 12V पावर सप्लाई व वायरिंग भी जांचें)।"
                            : lang === "mr"
                            ? "मातीमध्ये नत्र, स्फुरद व पालाश शून्य असल्याने पिकांची अनुकूलता १५% (अयोग्य) झाली आहे. पिकांसाठी तातडीने खत व्यवस्थापन करा. (टीप: सेन्सर नवीन असल्यास 12V RS485 Modbus वीजपुरवठा व वायरिंग तपासा)."
                            : "Soil currently has zero measurable macronutrients, so all crop suitability scores have dropped to 15% (unsuitable). Crops cannot grow without N-P-K; apply prescribed basal fertilizers from the Fertilizer tab. (Note: If using an RS485 Modbus probe, also verify 9–24V DC external probe power & wiring)."}
                        </p>
                      </div>
                    </div>
                  )}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mt-6">
                  {cropRecommendations.map((crop) => (
                    <div
                      key={crop.id}
                      className="bg-slate-50/70 rounded-xl p-5 border border-slate-200 hover:border-emerald-400 hover:bg-white hover:shadow-md transition flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-3">
                            <span className="text-3xl p-1 bg-white rounded-lg shadow-sm border border-slate-100">
                              {crop.icon}
                            </span>
                            <div>
                              <h3 className="font-bold text-base text-slate-900">{crop.displayName}</h3>
                              <span className="text-xs px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-medium">
                                {t.seasons[crop.season] || crop.season}
                              </span>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className={`text-xl font-black ${crop.matchScore >= 80 ? "text-emerald-700" : crop.matchScore >= 60 ? "text-lime-700" : crop.matchScore >= 45 ? "text-amber-600" : "text-rose-600"}`}>
                              {crop.matchScore}%
                            </span>
                            <span className="block text-[10px] text-slate-400 uppercase font-semibold">{t.cropsSnapshot.suitability}</span>
                          </div>
                        </div>

                        {/* Suitability Progress bar */}
                        <div className="w-full bg-slate-200 rounded-full h-2 mt-3 overflow-hidden">
                          <div
                            className={`h-2 rounded-full transition-all duration-700 ${
                              crop.matchScore >= 80 ? "bg-emerald-500" : crop.matchScore >= 60 ? "bg-lime-500" : crop.matchScore >= 45 ? "bg-amber-500" : "bg-rose-500"
                            }`}
                            style={{ width: `${crop.matchScore}%` }}
                          ></div>
                        </div>

                        <p className="mt-3 text-xs text-slate-600 leading-relaxed">
                          {crop.displayDesc}
                        </p>

                        <div className="mt-4 pt-3 border-t border-slate-200/70 grid grid-cols-2 gap-2 text-xs">
                          <div className="bg-white p-2 rounded-lg border border-slate-100">
                            <span className="text-slate-400 text-[11px] block">{t.cropSection.idealPH}</span>
                            <span className="font-semibold text-slate-700">{crop.minPh} - {crop.maxPh} pH</span>
                          </div>
                          <div className="bg-white p-2 rounded-lg border border-slate-100">
                            <span className="text-slate-400 text-[11px] block">{t.cropSection.idealMoisture}</span>
                            <span className="font-semibold text-slate-700">{crop.minMoist}% - {crop.maxMoist}%</span>
                          </div>
                          <div className="bg-white p-2 rounded-lg border border-slate-100">
                            <span className="text-slate-400 text-[11px] block">{t.cropSection.idealTemp}</span>
                            <span className="font-semibold text-slate-700">{crop.minTemp} - {crop.maxTemp} °C</span>
                          </div>
                          <div className="bg-white p-2 rounded-lg border border-slate-100">
                            <span className="text-slate-400 text-[11px] block">{t.cropSection.maxEc}</span>
                            <span className="font-semibold text-slate-700">&lt; {crop.maxEc} µS/cm</span>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between text-xs font-semibold">
                        <span className="text-slate-500">{t.cropTab.npkTarget}</span>
                        <span className="font-mono text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                          {crop.minN}-{crop.maxN} : {crop.minP}-{crop.maxP} : {crop.minK}-{crop.maxK}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
            </div>
          </div>
        )}

        {/* TAB 3: Fertilizer & Amendments */}
        {activeTab === "fertilizer" && (
          <div className="mt-6 space-y-6">
            {!sensorData || soilAnalysis?.isOfflineOrZero ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 shadow-sm">
                <div className="w-14 h-14 bg-amber-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
                  <Sparkles className="w-7 h-7 text-amber-600 animate-pulse" />
                </div>
                <h3 className="font-bold text-slate-800 text-lg">{t.fertilizerTab.awaitingTitle}</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 leading-relaxed">
                  {t.fertilizerTab.awaitingDesc}
                </p>
                <button
                  onClick={() => takeReadingFromEsp32(true)}
                  className="mt-4 px-4 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 transition"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{t.fertilizerTab.takeReading}</span>
                </button>
              </div>
            ) : (
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                <div className="border-b border-slate-100 pb-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                      <Sparkles className="w-6 h-6 text-amber-500" />
                      <span>{t.fertilizerSection.title}</span>
                    </h2>
                    <p className="text-sm text-slate-500 mt-1">
                      {t.fertilizerSection.subtitle}
                    </p>
                  </div>

                  {/* Target Crop Selector */}
                  <div className="flex items-center gap-2 bg-emerald-50/80 p-2 rounded-xl border border-emerald-200">
                    <span className="text-xs font-semibold text-emerald-900 whitespace-nowrap">
                      {t.fertilizerTab.cropSelectorLabel}
                    </span>
                    <select
                      value={selectedFertilizerCrop}
                      onChange={(e) => setSelectedFertilizerCrop(e.target.value)}
                      className="text-xs font-bold bg-white text-emerald-900 border border-emerald-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer shadow-sm"
                    >
                      <option value="auto">
                        🌟 {t.fertilizerTab.autoCrop} ({fertilizerAdvice.targetCrop ? (lang === "hi" ? fertilizerAdvice.targetCrop.nameHi : lang === "mr" ? fertilizerAdvice.targetCrop.nameMr : fertilizerAdvice.targetCrop.nameEn) : ""})
                      </option>
                      {CROP_DATABASE.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.icon} {lang === "hi" ? c.nameHi : lang === "mr" ? c.nameMr : c.nameEn} ({t.seasons[c.season] || c.season})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Section 1: Soil Physical & Chemical Condition Diagnosis */}
                <div className="mt-6 space-y-3">
                  <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                    <span>{t.fertilizerTab.soilDiagnosisTitle}</span>
                  </h3>

                  <div className="space-y-3">
                    {fertilizerAdvice.recommendations.map((rec, i) => (
                      <div 
                        key={i} 
                        className={`p-4 rounded-xl border flex items-start space-x-3 ${
                          rec.severity === "critical" 
                            ? "bg-rose-50/70 border-rose-200 text-rose-900" 
                            : rec.severity === "warning" 
                            ? "bg-amber-50/70 border-amber-200 text-amber-900" 
                            : "bg-emerald-50/60 border-emerald-200 text-emerald-900"
                        }`}
                      >
                        {rec.severity === "critical" ? (
                          <AlertTriangle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
                        ) : rec.severity === "warning" ? (
                          <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                        ) : (
                          <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                        )}
                        <div>
                          <h4 className="text-sm font-bold text-slate-900">
                            {lang === "hi" ? rec.titleHi : lang === "mr" ? rec.titleMr : rec.titleEn}
                          </h4>
                          <p className="text-xs text-slate-700 mt-1 leading-relaxed">
                            {lang === "hi" ? rec.actionHi : lang === "mr" ? rec.actionMr : rec.actionEn}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Section 2: Commercial Fertilizer Dosage Calculation Table */}
                <div className="mt-8">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3 gap-1">
                    <div>
                      <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                        <Layers className="w-4 h-4 text-emerald-600" />
                        <span>{t.fertilizerTab.cropDosingTitle}</span>
                      </h3>
                      <p className="text-xs text-slate-500">
                        {t.fertilizerTab.cropDosingSubtitle}: <b className="text-emerald-800">{fertilizerAdvice.targetCrop ? (lang === "hi" ? fertilizerAdvice.targetCrop.nameHi : lang === "mr" ? fertilizerAdvice.targetCrop.nameMr : fertilizerAdvice.targetCrop.nameEn) : ""}</b>
                      </p>
                    </div>
                    {fertilizerAdvice.targetCrop && (
                      <span className="text-xs font-mono bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg border border-slate-200 inline-block self-start">
                        N-P-K: {fertilizerAdvice.targetCrop.minN}-{fertilizerAdvice.targetCrop.maxN} : {fertilizerAdvice.targetCrop.minP}-{fertilizerAdvice.targetCrop.maxP} : {fertilizerAdvice.targetCrop.minK}-{fertilizerAdvice.targetCrop.maxK}
                      </span>
                    )}
                  </div>

                  {fertilizerAdvice.chemicalDoses.length === 0 ? (
                    <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-800 font-medium">
                      {t.fertilizerTab.allBalanced}
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-sm border-collapse">
                        <thead>
                          <tr className="bg-slate-100 text-slate-700 text-xs font-semibold uppercase">
                            <th className="py-3 px-4 rounded-l-lg">{t.fertilizerTab.colGrade}</th>
                            <th className="py-3 px-4">{t.fertilizerTab.colDose}</th>
                            <th className="py-3 px-4">{t.fertilizerTab.colMethod}</th>
                            <th className="py-3 px-4 rounded-r-lg">{t.fertilizerTab.colPriority}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
                          {fertilizerAdvice.chemicalDoses.map((dose, idx) => (
                            <tr key={idx} className="hover:bg-slate-50">
                              <td className="py-3 px-4 font-bold text-slate-800">
                                {lang === "hi" ? dose.nameHi : lang === "mr" ? dose.nameMr : dose.nameEn}
                              </td>
                              <td className="py-3 px-4 font-mono font-bold text-emerald-800">
                                {dose.dose}
                              </td>
                              <td className="py-3 px-4 text-slate-600">
                                {lang === "hi" ? dose.timingHi : lang === "mr" ? dose.timingMr : dose.timingEn}
                              </td>
                              <td className="py-3 px-4">
                                <span className={`px-2 py-0.5 rounded text-xs font-bold border ${
                                  dose.tag === "Avoid"
                                    ? "bg-rose-100 text-rose-800 border-rose-300"
                                    : dose.tag === "Urgent" || dose.tag === "Critical for Nodules"
                                    ? "bg-amber-100 text-amber-800 border-amber-300"
                                    : dose.tag === "Starter N"
                                    ? "bg-blue-100 text-blue-800 border-blue-300"
                                    : dose.tag === "Saline-Safe" || dose.tag === "Soil-Adapted"
                                    ? "bg-purple-100 text-purple-800 border-purple-300"
                                    : "bg-emerald-100 text-emerald-800 border-emerald-300"
                                }`}>
                                  {lang === "hi" ? (dose.tagHi || dose.tag) : lang === "mr" ? (dose.tagMr || dose.tag) : dose.tag}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {/* Organic & Bio-fertilizer Advisory Box */}
                <div className="mt-8 p-5 bg-emerald-50/70 rounded-2xl border border-emerald-200">
                  <h3 className="font-bold text-emerald-900 text-sm flex items-center gap-2 mb-2">
                    <Sprout className="w-5 h-5 text-emerald-700" />
                    <span>{t.fertilizerSection.organicRemedy}</span>
                  </h3>
                  <ul className="text-xs text-slate-700 space-y-2 list-disc pl-5 leading-relaxed">
                    {t.organicAdvice.map((item, idx) => (
                      <li key={idx}>
                        <strong>{item.name}:</strong> {item.desc}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: Soil Health Card Tab */}
        {activeTab === "healthCard" && (
          <div className="mt-6 space-y-6">
            {!sensorData || soilAnalysis?.isOfflineOrZero ? (
              <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 shadow-sm">
                <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-3">
                  <Printer className="w-7 h-7 text-emerald-700 animate-pulse" />
                </div>
                <h3 className="font-bold text-slate-800 text-lg">{t.healthCard.awaitingTitle}</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 leading-relaxed">
                  {t.healthCard.awaitingDesc}
                </p>
                <button
                  onClick={() => takeReadingFromEsp32(true)}
                  className="mt-4 px-4 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 transition"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{t.cropTab.takeReading}</span>
                </button>
              </div>
            ) : (
              <>
                <div className="flex justify-end">
                  <button
                    onClick={() => window.print()}
                    className="flex items-center space-x-2 bg-emerald-700 hover:bg-emerald-800 text-white px-4 py-2 rounded-xl text-sm font-semibold shadow-sm transition"
                  >
                    <Printer className="w-4 h-4" />
                    <span>{t.printCard}</span>
                  </button>
                </div>

                {/* Printable Container Formatted as Indian Soil Health Card */}
                <div className="bg-white rounded-2xl p-6 sm:p-10 shadow-sm border border-slate-300 print:border-none print:shadow-none print:p-0">
                  {/* Header */}
                  <div className="border-b-2 border-emerald-800 pb-5 text-center relative">
                    <div className="inline-block p-2 bg-emerald-100 rounded-full mb-2">
                      <Sprout className="w-8 h-8 text-emerald-800" />
                    </div>
                    <h2 className="text-2xl font-black text-emerald-900 tracking-tight">
                      {t.healthCard.title}
                    </h2>
                    <p className="text-xs text-slate-500 font-medium uppercase tracking-widest mt-1">
                      {t.healthCard.subtitle}
                    </p>
                    <div className="mt-3 flex justify-between text-xs text-slate-500 font-mono">
                      <span>{t.healthCard.cardId}: BM-SHC-{Math.round((sensorData?.nitrogen || 10) * 12)}</span>
                      <span>{t.healthCard.date}: {new Date().toLocaleDateString(lang === "mr" ? "mr-IN" : lang === "hi" ? "hi-IN" : "en-IN")}</span>
                      <span>{t.healthCard.location}</span>
                    </div>
                  </div>

                  {/* Farmer and Field Sample Profile */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-4 border-b border-slate-200 text-xs">
                    <div>
                      <span className="text-slate-400 block font-medium">{t.healthCard.farmerName}</span>
                      <span className="font-bold text-slate-800">{t.healthCard.farmerNameVal}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-medium">{t.healthCard.surveyNo}</span>
                      <span className="font-bold text-slate-800">{t.healthCard.surveyNoVal}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-medium">{t.healthCard.healthIndex}</span>
                      <span className={`font-bold text-sm ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getScoreColor(soilAnalysis.totalScore) : "text-slate-700"}`}>
                        {soilAnalysis && !soilAnalysis.isOfflineOrZero ? `${soilAnalysis.totalScore} / 100 (${t.scoreRemarks[soilAnalysis.category]})` : `0 / 100 (${t.scoreBands.awaitingBadge})`}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-medium">{t.healthCard.testMethod}</span>
                      <span className="font-bold text-slate-800">{t.healthCard.testMethodVal}</span>
                    </div>
                  </div>

                  {/* Standard Parameter Table */}
                  <div className="mt-6">
                    <h3 className="font-bold text-sm text-slate-800 uppercase tracking-wider mb-3">
                      {t.healthCard.tableTitle}
                    </h3>
                    <table className="w-full text-left text-xs border border-slate-200">
                      <thead className="bg-slate-100 text-slate-700">
                        <tr className="border-b border-slate-200">
                          <th className="py-2.5 px-3">{t.healthCard.colParam}</th>
                          <th className="py-2.5 px-3">{t.healthCard.colValue}</th>
                          <th className="py-2.5 px-3">{t.healthCard.colRange}</th>
                          <th className="py-2.5 px-3">{t.healthCard.colStatus}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        <tr>
                          <td className="py-2.5 px-3 font-semibold">{t.parameters.n.label}</td>
                          <td className="py-2.5 px-3 font-bold">{sensorData.nitrogen} {t.parameters.n.unit}</td>
                          <td className="py-2.5 px-3 text-slate-500">100 - 220 {t.parameters.n.unit}</td>
                          <td className={`py-2.5 px-3 font-semibold ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.nStatus) : ""}`}>{soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.nStatus] : t.measurements.pending}</td>
                        </tr>
                        <tr>
                          <td className="py-2.5 px-3 font-semibold">{t.parameters.p.label}</td>
                          <td className="py-2.5 px-3 font-bold">{sensorData.phosphorus} {t.parameters.p.unit}</td>
                          <td className="py-2.5 px-3 text-slate-500">25 - 60 {t.parameters.p.unit}</td>
                          <td className={`py-2.5 px-3 font-semibold ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.pStatus) : ""}`}>{soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.pStatus] : t.measurements.pending}</td>
                        </tr>
                        <tr>
                          <td className="py-2.5 px-3 font-semibold">{t.parameters.k.label}</td>
                          <td className="py-2.5 px-3 font-bold">{sensorData.potassium} {t.parameters.k.unit}</td>
                          <td className="py-2.5 px-3 text-slate-500">120 - 250 {t.parameters.k.unit}</td>
                          <td className={`py-2.5 px-3 font-semibold ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.kStatus) : ""}`}>{soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.kStatus] : t.measurements.pending}</td>
                        </tr>
                        <tr>
                          <td className="py-2.5 px-3 font-semibold">{t.parameters.ph.label}</td>
                          <td className="py-2.5 px-3 font-bold">{sensorData.ph} pH</td>
                          <td className="py-2.5 px-3 text-slate-500">6.2 - 7.5 ({t.status.neutral})</td>
                          <td className={`py-2.5 px-3 font-semibold ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.phStatus) : ""}`}>{soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.phStatus] : t.measurements.pending}</td>
                        </tr>
                        <tr>
                          <td className="py-2.5 px-3 font-semibold">{t.parameters.moisture.label}</td>
                          <td className="py-2.5 px-3 font-bold">{sensorData.moisture} %</td>
                          <td className="py-2.5 px-3 text-slate-500">35% - 60%</td>
                          <td className={`py-2.5 px-3 font-semibold ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.mStatus) : ""}`}>{soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.mStatus] : t.measurements.pending}</td>
                        </tr>
                        <tr>
                          <td className="py-2.5 px-3 font-semibold">{t.parameters.temp.label}</td>
                          <td className="py-2.5 px-3 font-bold">{sensorData.temperature} °C</td>
                          <td className="py-2.5 px-3 text-slate-500">18 - 32 °C</td>
                          <td className={`py-2.5 px-3 font-semibold ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.tempStatus) : ""}`}>{soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.tempStatus] : t.measurements.pending}</td>
                        </tr>
                        <tr>
                          <td className="py-2.5 px-3 font-semibold">{t.parameters.ec.label}</td>
                          <td className="py-2.5 px-3 font-bold">{sensorData.ec} {t.parameters.ec.unit}</td>
                          <td className="py-2.5 px-3 text-slate-500">&lt; 1000 {t.parameters.ec.unit}</td>
                          <td className={`py-2.5 px-3 font-semibold ${soilAnalysis && !soilAnalysis.isOfflineOrZero ? getStatusTextClass(soilAnalysis.ecStatus) : ""}`}>{soilAnalysis && !soilAnalysis.isOfflineOrZero ? t.status[soilAnalysis.ecStatus] : t.measurements.pending}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* Recommended Crops & Fertilizers */}
                  <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
                    <div className="border border-slate-200 rounded-xl p-4 bg-slate-50">
                      <h4 className="font-bold text-slate-800 uppercase mb-2">{t.healthCard.topCrops}</h4>
                      <ul className="space-y-1.5 list-disc pl-4 text-slate-700">
                        {cropRecommendations.length > 0 ? (
                          cropRecommendations.slice(0, 3).map((crop) => (
                            <li key={crop.id}>
                              <span className="font-semibold">{crop.displayName}</span> — {crop.matchScore}% {t.cropsSnapshot.suitability} ({t.seasons[crop.season] || crop.season})
                            </li>
                          ))
                        ) : (
                          <li className="text-slate-400 italic list-none -ml-4">{t.cropsSnapshot.awaitingTitle}</li>
                        )}
                      </ul>
                    </div>

                    <div className="border border-slate-200 rounded-xl p-4 bg-slate-50">
                      <h4 className="font-bold text-slate-800 uppercase mb-2">{t.healthCard.prescribedDose}</h4>
                      <ul className="space-y-1.5 list-disc pl-4 text-slate-700">
                        {fertilizerAdvice.chemicalDoses.length > 0 ? (
                          fertilizerAdvice.chemicalDoses.map((dose, i) => (
                            <li key={i}>
                              <span className="font-semibold">{lang === "hi" ? dose.nameHi : lang === "mr" ? dose.nameMr : dose.nameEn}:</span> {dose.dose}
                            </li>
                          ))
                        ) : (
                          <li className="text-slate-400 italic list-none -ml-4">{t.fertilizerTab.awaitingTitle}</li>
                        )}
                        <li>
                          <span className="font-semibold">{t.healthCard.organicFym}</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  {/* Stamp and Signature Footer */}
                  <div className="mt-10 pt-6 border-t border-slate-200 flex justify-between items-end text-xs text-slate-500">
                    <div>
                      <p className="font-semibold text-slate-700">{t.healthCard.unitName}</p>
                      <p>{t.healthCard.certAnalysis}</p>
                    </div>
                    <div className="text-center">
                      <div className="w-36 border-b border-slate-400 mb-1"></div>
                      <p className="font-semibold text-slate-700">{t.healthCard.authSign}</p>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        )}
      </main>

      {}
      {showConfigModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center space-x-2">
                <Sliders className="w-5 h-5 text-emerald-700" />
                <h3 className="font-bold text-slate-900 text-lg">{t.configModal.title}</h3>
              </div>
              <button
                onClick={() => setShowConfigModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                ✕
              </button>
            </div>

            {/* Direct ESP32 Station Connection (Zero Cloud / Zero Supabase) */}
            <div className="mt-4 p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                  <Cpu className="w-4 h-4 text-emerald-700" />
                  {t.configModal.cloudBackend}
                </span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${hardwareConnected ? "bg-emerald-200 text-emerald-800" : "bg-rose-200 text-rose-800"}`}>
                  {hardwareConnected ? t.configModal.connected : t.configModal.disconnected}
                </span>
              </div>
              <p className="text-[11px] text-emerald-800 mb-3">
                {t.configModal.localIpDesc}
              </p>

              <label className="font-bold text-slate-700 block mb-1">{t.configModal.localIpLabel}</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={espIp}
                  onChange={(e) => setEspIp(e.target.value)}
                  className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded-lg font-mono text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  placeholder="e.g. 192.168.4.1 or 192.168.1.150"
                />
                <button
                  onClick={() => takeReadingFromEsp32(true)}
                  disabled={isTakingReading}
                  className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold flex items-center gap-1 transition"
                >
                  <RefreshCw className={`w-3 h-3 ${isTakingReading ? "animate-spin" : ""}`} />
                  <span>{isTakingReading ? t.liveSync.readingNow : t.configModal.fetchNow}</span>
                </button>
              </div>

              <div className="mt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setEspIp("192.168.4.1")}
                  className="text-[11px] text-emerald-700 hover:underline font-semibold"
                >
                  {t.configModal.softApPreset}
                </button>
              </div>

              {/* USB Serial Option */}
              {isWebSerialSupported && (
                <div className="mt-3 pt-3 border-t border-emerald-200/70">
                  <span className="font-bold text-slate-700 block mb-1">{t.configModal.usbSerialLabel}</span>
                  <p className="text-[11px] text-slate-500 mb-2">{t.configModal.usbSerialDesc}</p>
                  <button
                    onClick={connectUsbSerial}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
                      usbConnected
                        ? "bg-rose-600 hover:bg-rose-700 text-white"
                        : "bg-blue-600 hover:bg-blue-700 text-white"
                    }`}
                  >
                    <Usb className="w-3.5 h-3.5" />
                    <span>{usbConnected ? t.liveSync.usbDisconnect : t.liveSync.usbConnect}</span>
                  </button>
                </div>
              )}

              {/* Auto Refresh Option */}
              <div className="mt-3 pt-3 border-t border-emerald-200/70">
                <label className="flex items-start gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoRefresh}
                    onChange={(e) => setAutoRefresh(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500 h-4 w-4 mt-0.5"
                  />
                  <div>
                    <span className="font-bold text-slate-800 block">{t.configModal.autoRefreshLabel}</span>
                    <span className="text-[11px] text-slate-500 block leading-tight">{t.configModal.autoRefreshDesc}</span>
                  </div>
                </label>
              </div>

              {sensorStatus.errorMessage && (
                <div className="mt-3 p-2 bg-rose-50 border border-rose-200 text-rose-700 rounded text-[11px]">
                  ⚠️ {sensorStatus.errorMessage}
                </div>
              )}
            </div>

            {/* Manual Sliders for Testing Scenarios */}
            <div className="mt-5 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-700 uppercase">{t.configModal.testValues}</span>
                <button
                  onClick={() => setSensorData(DEFAULT_SENSORS)}
                  className="text-xs text-emerald-700 hover:underline font-semibold"
                >
                  {t.resetDefaults}
                </button>
              </div>

              {/* Nitrogen Slider */}
              <div>
                <div className="flex justify-between text-xs mb-1 font-semibold text-slate-700">
                  <span>{t.parameters.n.label}: {sensorData?.nitrogen ?? "--"} {t.parameters.n.unit}</span>
                  <span className="text-slate-400">10 - 300</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="300"
                  value={sensorData?.nitrogen ?? DEFAULT_SENSORS.nitrogen}
                  onChange={(e) => {
                    setIsLiveStreaming(false);
                    setSensorData({ ...(sensorData || DEFAULT_SENSORS), nitrogen: Number(e.target.value) });
                  }}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              {/* Phosphorus Slider */}
              <div>
                <div className="flex justify-between text-xs mb-1 font-semibold text-slate-700">
                  <span>{t.parameters.p.label}: {sensorData?.phosphorus ?? "--"} {t.parameters.p.unit}</span>
                  <span className="text-slate-400">5 - 100</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="100"
                  value={sensorData?.phosphorus ?? DEFAULT_SENSORS.phosphorus}
                  onChange={(e) => {
                    setIsLiveStreaming(false);
                    setSensorData({ ...(sensorData || DEFAULT_SENSORS), phosphorus: Number(e.target.value) });
                  }}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              {/* Potassium Slider */}
              <div>
                <div className="flex justify-between text-xs mb-1 font-semibold text-slate-700">
                  <span>{t.parameters.k.label}: {sensorData?.potassium ?? "--"} {t.parameters.k.unit}</span>
                  <span className="text-slate-400">30 - 400</span>
                </div>
                <input
                  type="range"
                  min="30"
                  max="400"
                  value={sensorData?.potassium ?? DEFAULT_SENSORS.potassium}
                  onChange={(e) => {
                    setIsLiveStreaming(false);
                    setSensorData({ ...(sensorData || DEFAULT_SENSORS), potassium: Number(e.target.value) });
                  }}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              {/* pH Slider */}
              <div>
                <div className="flex justify-between text-xs mb-1 font-semibold text-slate-700">
                  <span>{t.parameters.ph.label}: {sensorData?.ph ?? "--"}</span>
                  <span className="text-slate-400">4.5 - 9.0</span>
                </div>
                <input
                  type="range"
                  min="4.5"
                  max="9.0"
                  step="0.1"
                  value={sensorData?.ph ?? DEFAULT_SENSORS.ph}
                  onChange={(e) => {
                    setIsLiveStreaming(false);
                    setSensorData({ ...(sensorData || DEFAULT_SENSORS), ph: Number(e.target.value) });
                  }}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              {/* Moisture Slider */}
              <div>
                <div className="flex justify-between text-xs mb-1 font-semibold text-slate-700">
                  <span>{t.parameters.moisture.label}: {sensorData?.moisture != null ? `${sensorData.moisture}%` : "--"}</span>
                  <span className="text-slate-400">5 - 95%</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="95"
                  value={sensorData?.moisture ?? DEFAULT_SENSORS.moisture}
                  onChange={(e) => {
                    setIsLiveStreaming(false);
                    setSensorData({ ...(sensorData || DEFAULT_SENSORS), moisture: Number(e.target.value) });
                  }}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              {/* Soil Temperature */}
              <div>
                <div className="flex justify-between text-xs mb-1 font-semibold text-slate-700">
                  <span>{t.parameters.temp.label}: {sensorData?.temperature != null ? `${sensorData.temperature}°C` : "--"}</span>
                  <span className="text-slate-400">12 - 45°C</span>
                </div>
                <input
                  type="range"
                  min="12"
                  max="45"
                  step="0.5"
                  value={sensorData?.temperature ?? DEFAULT_SENSORS.temperature}
                  onChange={(e) => {
                    setIsLiveStreaming(false);
                    setSensorData({ ...(sensorData || DEFAULT_SENSORS), temperature: Number(e.target.value) });
                  }}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-2">
              <button
                onClick={() => setShowConfigModal(false)}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition"
              >
                {t.configModal.applyBtn}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
