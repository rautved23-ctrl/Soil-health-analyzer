import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const espIp = env.VITE_ESP32_IP || '192.168.4.1';

  return {
    plugins: [
      react(),
      tailwindcss(),
    ],
    server: {
      host: true,
      port: 5173,
      proxy: {
        '/esp-proxy': {
          target: `http://${espIp}`,
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/esp-proxy/, '')
        }
      }
    }
  };
});
